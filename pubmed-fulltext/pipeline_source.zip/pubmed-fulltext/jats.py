"""Parse JATS XML into sections, tables (grid with row/col spans), references and supplementary material."""
import copy, re
from lxml import etree

XLINK = "{http://www.w3.org/1999/xlink}"
DOI_RE = re.compile(r"\b(10\.\d{4,9}/[^\s\"<>]+)", re.I)


def _strip_ns(root):
    for el in root.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return root


def _t(el):
    return " ".join("".join(el.itertext()).split()) if el is not None else ""


def _href(el):
    if el is None:
        return None
    return el.get(XLINK + "href") or next((v for k, v in el.attrib.items() if k.endswith("href")), None)


def load(xml_bytes):
    root = etree.fromstring(xml_bytes, parser=etree.XMLParser(recover=True, huge_tree=True))
    root = _strip_ns(root)
    art = root if root.tag == "article" else root.find(".//article")
    return art


def license_info(art, fallback=None):
    """Licence from the article's own XML (license/@href, ali:license_ref, ext-link inside the licence text)."""
    lic = art.find(".//article-meta/permissions/license")
    urls = []
    if lic is not None:
        urls += [_href(lic)] + [_href(x) for x in lic.iter("ext-link")]
    urls += [_t(x) for x in art.findall(".//article-meta/permissions//license_ref")]
    urls = [u for u in urls if u]
    text = _t(lic)[:400] if lic is not None else ""
    url = next((u for u in urls if "creativecommons.org" in u), urls[0] if urls else None)
    label = None
    m = re.search(r"creativecommons\.org/(licenses|publicdomain)/([a-z\-]+)/?([\d.]+)?", url or "", re.I)
    if m:
        label = ("CC0" if m.group(1).lower() == "publicdomain" else "CC " + m.group(2).upper()) + (" " + m.group(3) if m.group(3) else "")
    elif re.search(r"creative commons attribution", text, re.I):
        parts = ["BY"]
        if re.search(r"non-?commercial", text, re.I): parts.append("NC")
        if re.search(r"no-?deriv", text, re.I): parts.append("ND")
        if re.search(r"share-?alike", text, re.I): parts.append("SA")
        v = re.search(r"attribution[^.]*?(\d\.\d)", text, re.I)
        label = "CC " + "-".join(parts) + (" " + v.group(1) if v else "")
    elif fallback:
        label = fallback.upper() + " (Europe PMC)"
    return {"license_url": url, "license_label": label, "license_text": text}


BACK = re.compile(r"^(references?|associated data|footnotes?|acknowledge?ments?|contributor information|author contributions?|"
                  r"competing interests?|conflicts? of interest|data availability|data sharing statement|funding|"
                  r"supplementary (information|material|data)|online content|disclosures?|sources? of funding|ethics)", re.I)


def sections(art):
    body = art.find("body")
    if body is None:
        return []
    out = []
    secs = body.findall("sec")
    if not secs:
        return [{"title": "(body without section headings)", "words": len(_t(body).split()), "subsections": 0, "kind": "main"}]
    for s in secs:
        c = copy.deepcopy(s)
        for bad in c.findall(".//table-wrap") + c.findall(".//fig"):
            bad.getparent().remove(bad)
        title = _t(c.find("title")) or "(untitled section)"
        tl = c.find("title")
        if tl is not None:
            c.remove(tl)
        kind = "back matter" if (BACK.match(title) or title == "(untitled section)") else "main"
        out.append({"title": title, "words": len(_t(c).split()), "subsections": len(s.findall(".//sec")), "kind": kind})
    return out


def _grid(rows, header_n):
    grid, pending = [], {}
    for ri, tr in enumerate(rows):
        row, col = [], 0
        cells = [c for c in tr if c.tag in ("td", "th")]
        is_head = ri < header_n
        for cell in cells:
            while col in pending:
                rem, txt = pending[col]; row.append(txt)
                pending[col] = (rem - 1, txt) if rem > 1 else None
                if pending[col] is None: del pending[col]
                col += 1
            txt = _t(cell)
            try: cs = max(1, int(cell.get("colspan", 1)))
            except ValueError: cs = 1
            try: rs = max(1, int(cell.get("rowspan", 1)))
            except ValueError: rs = 1
            for k in range(min(cs, 50)):
                v = txt if (k == 0 or is_head) else ""
                row.append(v)
                if rs > 1: pending[col] = (rs - 1, v)
                col += 1
        while col in pending:
            rem, txt = pending[col]; row.append(txt)
            pending[col] = (rem - 1, txt) if rem > 1 else None
            if pending[col] is None: del pending[col]
            col += 1
        grid.append(row)
    w = max((len(r) for r in grid), default=0)
    return [r + [""] * (w - len(r)) for r in grid]


def tables(art):
    out = []
    for i, tw in enumerate(art.iter("table-wrap"), 1):
        label = _t(tw.find("label")) or f"Table {i}"
        cap = tw.find("caption")
        caption = _t(cap)
        foot = _t(tw.find("table-wrap-foot"))
        tbl = tw.find(".//table")
        if tbl is None:
            out.append({"label": label, "caption": caption, "footnote": foot, "rows": None,
                        "note": "table supplied as an image only (no cell data in the XML)"})
            continue
        head = tbl.findall(".//thead/tr")
        body = [tr for tr in tbl.iter("tr") if tr.getparent().tag != "thead"]
        grid = _grid(head + body, len(head) or 1)
        out.append({"label": label, "caption": caption, "footnote": foot, "rows": grid, "header_rows": len(head) or 1})
    return out


def references(art):
    refs = []
    for r in art.iter("ref"):
        doi = pmid = None
        for pid in r.iter("pub-id"):
            t = (pid.get("pub-id-type") or "").lower()
            if t == "doi" and not doi: doi = _t(pid).lower()
            if t == "pmid" and not pmid: pmid = _t(pid)
        if not doi:
            for x in r.iter("ext-link"):
                m = DOI_RE.search(_href(x) or _t(x))
                if m: doi = m.group(1).rstrip(".").lower(); break
        if not doi:
            m = DOI_RE.search(_t(r))
            if m: doi = m.group(1).rstrip(".,;").lower()
        refs.append({"doi": doi, "pmid": pmid})
    return refs


def supplements(art, pmcid):
    out, seen = [], set()
    for sm in art.iter("supplementary-material"):
        files = [_href(sm)] + [_href(m) for m in sm.iter("media")]
        href = next((f for f in files if f), None)
        if href and href in seen:
            continue
        seen.add(href)
        out.append({"label": _t(sm.find("label")) or _t(sm.find("caption/title")) or "Supplementary material",
                    "caption": _t(sm.find("caption"))[:200], "file": href,
                    "url": f"https://pmc.ncbi.nlm.nih.gov/articles/{pmcid}/bin/{href}" if href and not href.startswith("http") else href})
    return out
