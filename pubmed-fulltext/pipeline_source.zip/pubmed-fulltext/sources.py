"""Official open APIs only: NCBI E-utilities, PMC ID Converter, PMC OAI-PMH, Europe PMC REST, Crossref REST, Unpaywall."""
import json, re
from lxml import etree
from polite import get, TOOL, EMAIL

EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"


def norm_doi(s):
    if not s:
        return None
    s = s.strip()
    s = re.sub(r"^(https?://)?(dx\.)?doi\.org/", "", s, flags=re.I)
    s = re.sub(r"^doi:\s*", "", s, flags=re.I)
    return s.lower() or None


def idconv(ids, idtype):
    """PMC ID Converter. Returns {requested_id: {pmid, pmcid, doi} or {error}}. Batches of 100."""
    out = {}
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        params = {"ids": ",".join(chunk), "format": "json", "tool": TOOL, "email": EMAIL}
        if idtype != "pmid":
            params["idtype"] = idtype
        st, txt = get("https://pmc.ncbi.nlm.nih.gov/tools/idconv/api/v1/articles/", params=params)
        if st != 200:
            for c in chunk:
                out[c] = {"error": f"ID converter HTTP {st}"}
            continue
        for r in json.loads(txt).get("records", []):
            req = str(r.get("requested-id"))
            if r.get("status") == "error":
                out[req] = {"error": r.get("errmsg", "error")}
            else:
                out[req] = {"pmid": str(r["pmid"]) if r.get("pmid") else None, "pmcid": r.get("pmcid"),
                            "doi": norm_doi(r.get("doi"))}
    return out


def pubmed_pmid_for_doi(doi):
    st, txt = get(EUTILS + "esearch.fcgi", params={"db": "pubmed", "term": f'"{doi}"[doi]', "retmode": "json",
                                                     "tool": TOOL, "email": EMAIL})
    if st != 200:
        return None
    ids = json.loads(txt)["esearchresult"]["idlist"]
    return ids[0] if len(ids) == 1 else None


def _t(el):
    return " ".join("".join(el.itertext()).split()) if el is not None else ""


def pubmed_records(pmids):
    """efetch PubMed XML (POST, batches of 100): title, journal, year, author count, abstract, DOI, PMCID."""
    out = {}
    for i in range(0, len(pmids), 100):
        chunk = pmids[i:i + 100]
        st, txt = get(EUTILS + "efetch.fcgi", data={"db": "pubmed", "id": ",".join(chunk), "retmode": "xml",
                                                     "tool": TOOL, "email": EMAIL})
        if st != 200:
            continue
        root = etree.fromstring(txt.encode())
        for art in root.iter("PubmedArticle"):
            pmid = art.findtext("MedlineCitation/PMID")
            a = art.find("MedlineCitation/Article")
            pd = a.find("Journal/JournalIssue/PubDate")
            year = pd.findtext("Year") if pd is not None else None
            if not year and pd is not None:
                m = re.search(r"\d{4}", pd.findtext("MedlineDate") or "")
                year = m.group(0) if m else None
            ids = {x.get("IdType"): x.text for x in art.findall("PubmedData/ArticleIdList/ArticleId")}
            authors = [x for x in a.findall("AuthorList/Author") if x.find("LastName") is not None or x.find("CollectiveName") is not None]
            abstract = " ".join(_t(x) for x in a.findall("Abstract/AbstractText"))
            out[pmid] = {"pmid": pmid, "title": _t(a.find("ArticleTitle")), "journal": a.findtext("Journal/Title"),
                         "journal_abbrev": a.findtext("Journal/ISOAbbreviation"), "year": int(year) if year else None,
                         "n_authors": len(authors), "abstract_words": len(abstract.split()),
                         "doi": norm_doi(ids.get("doi")), "pmcid": ids.get("pmc"),
                         "pub_types": [x.text for x in a.findall("PublicationTypeList/PublicationType")]}
    return out


def crossref(doi):
    st, txt = get(f"https://api.crossref.org/works/{doi}", params={"mailto": EMAIL})
    if st != 200:
        return None
    m = json.loads(txt)["message"]
    def yr(k):
        dp = (m.get(k) or {}).get("date-parts") or [[None]]
        return dp[0][0]
    sub = " ".join((m.get("subtitle") or [""])[0].split())
    return {"title": " ".join((m.get("title") or [""])[0].split()), "subtitle": sub, "journal": (m.get("container-title") or [None])[0],
            "journal_short": (m.get("short-container-title") or [None])[0], "year_issued": yr("issued"),
            "year_print": yr("published-print"), "year_online": yr("published-online"),
            "publisher": m.get("publisher"), "type": m.get("type"),
            "licenses": sorted({l.get("URL") for l in m.get("license", []) if l.get("URL")})}


def unpaywall(doi):
    st, txt = get(f"https://api.unpaywall.org/v2/{doi}", params={"email": EMAIL})
    if st != 200:
        return None
    d = json.loads(txt)
    best = d.get("best_oa_location") or {}
    return {"is_oa": d.get("is_oa"), "oa_status": d.get("oa_status"), "best_host": best.get("host_type"),
            "best_license": best.get("license"), "best_version": best.get("version"),
            "best_repository": best.get("repository_institution")}


def europepmc(pmids):
    """Europe PMC core records for a list of PMIDs: pmcid, isOpenAccess, license, inPMC, inEPMC, hasSuppl."""
    out = {}
    for i in range(0, len(pmids), 25):
        chunk = pmids[i:i + 25]
        q = "SRC:MED AND EXT_ID:(" + " OR ".join(chunk) + ")"
        st, txt = get("https://www.ebi.ac.uk/europepmc/webservices/rest/search",
                      params={"query": q, "resultType": "core", "format": "json", "pageSize": 100})
        if st != 200:
            continue
        for r in json.loads(txt)["resultList"]["result"]:
            out[r.get("pmid")] = {"pmcid": r.get("pmcid"), "is_oa": r.get("isOpenAccess") == "Y",
                                  "license": r.get("license"), "in_pmc": r.get("inPMC") == "Y",
                                  "in_epmc": r.get("inEPMC") == "Y", "has_suppl": r.get("hasSuppl") == "Y"}
    return out


def fulltext_xml(pmcid):
    """JATS XML for an open-access PMC article: PMC OAI-PMH (pmc format, full front/body/back) first,
    Europe PMC fullTextXML as fallback. Returns (source, bytes) or (None, reason)."""
    st, txt = get("https://pmc.ncbi.nlm.nih.gov/api/oai/v1/mh/",
                  params={"verb": "GetRecord", "identifier": f"oai:pubmedcentral.nih.gov:{pmcid[3:]}", "metadataPrefix": "pmc"})
    if st == 200 and "<body" in txt:
        return "PMC OAI-PMH (JATS)", txt.encode()
    st2, txt2 = get(f"https://www.ebi.ac.uk/europepmc/webservices/rest/{pmcid}/fullTextXML")
    if st2 == 200 and "<body" in txt2:
        return "Europe PMC fullTextXML", txt2.encode()
    return None, f"no full-text XML (PMC OAI HTTP {st}, Europe PMC HTTP {st2})"
