"""Copy the run outputs into the public site folder (data.json for the page + downloads).
Tables from articles under a NonCommercial (NC) licence are extracted and counted, but their CSVs are not
republished on the public page; the client's own private copy keeps them."""
import csv, io, json, pathlib, shutil, zipfile

HERE = pathlib.Path(__file__).parent
OUT = HERE / "out"
SITE = HERE.parents[1] / "site" / "pubmed-fulltext"
SITE.mkdir(exist_ok=True)


def republish_ok(lic):
    return bool(lic) and lic.startswith("CC") and "NC" not in lic


d = json.loads((OUT / "articles.json").read_text())
cov = json.loads((OUT / "coverage.json").read_text())
keep = []
for a in d["articles"]:
    for t in a["tables"]:
        t["csv_public"] = bool(t["file"]) and republish_ok(a["license"])
        if t["file"] and not t["csv_public"]:
            t["public_note"] = f"extracted ({t['n_rows']} rows x {t['n_cols']} columns); CSV not republished here because the licence ({a['license']}) is non-commercial"
        if t["csv_public"]:
            keep.append(t["file"])
d["summary"]["tables_csv_public"] = len(keep)
page = {"summary": d["summary"], "merges": d["merges"], "coverage": cov,
        "articles": [{k: v for k, v in a.items() if k != "ref_ids"} | {"ref_ids_sample": [x for x in a["ref_ids"] if x][:8]}
                     for a in d["articles"]]}
(SITE / "data.json").write_text(json.dumps(page, ensure_ascii=False, separators=(",", ":")))
(SITE / "articles.json").write_text(json.dumps(d, indent=1, ensure_ascii=False))
shutil.copy(OUT / "coverage.csv", SITE / "coverage.csv")
# tables index with a public flag, tables folder and zip with the republishable CSVs only
rows = list(csv.DictReader(open(OUT / "tables_index.csv", encoding="utf-8")))
for r in rows:
    r["csv_in_this_zip"] = "yes" if r["file"] in keep else ("no (non-commercial licence)" if r["file"] else "no (image-only table)")
buf = io.StringIO(); w = csv.DictWriter(buf, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
(SITE / "tables_index.csv").write_text(buf.getvalue(), encoding="utf-8")
if (SITE / "tables").exists():
    shutil.rmtree(SITE / "tables")
(SITE / "tables").mkdir()
for f in keep:
    shutil.copy(OUT / "tables" / f, SITE / "tables" / f)
with zipfile.ZipFile(SITE / "tables.zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.write(SITE / "tables_index.csv", "tables_index.csv")
    for f in sorted(keep):
        z.write(SITE / "tables" / f, f"tables/{f}")
with zipfile.ZipFile(SITE / "pipeline_source.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for f in ("polite.py", "sources.py", "jats.py", "pipeline.py", "build_inputs.py", "publish.py", "inputs.csv", "query.json"):
        z.write(HERE / f, f"pubmed-fulltext/{f}")
size = sum(p.stat().st_size for p in SITE.rglob("*") if p.is_file())
print("public CSVs:", len(keep), "| site folder:", round(size / 1024), "KB")
