"""Proof of concept: input IDs -> ID resolution -> metadata cross-check -> open-access check -> JATS full text
(sections, tables, references, supplements) -> dedupe -> coverage report.  Open-access copies only."""
import csv, json, pathlib, re, shutil, zipfile, datetime
from difflib import SequenceMatcher
import polite
from sources import norm_doi, idconv, pubmed_pmid_for_doi, pubmed_records, crossref, unpaywall, europepmc, fulltext_xml
import jats

HERE = pathlib.Path(__file__).parent
OUT = HERE / "out"
if OUT.exists():
    shutil.rmtree(OUT)
(OUT / "tables").mkdir(parents=True)

inputs = list(csv.DictReader(open(HERE / "inputs.csv")))
query = json.loads((HERE / "query.json").read_text())

# ---- 1. ID resolution -------------------------------------------------------------------------
for i, r in enumerate(inputs, 1):
    r["n"] = i
    raw = r["input_id"].strip()
    if re.fullmatch(r"\d+", raw):
        r["kind"], r["key"] = "pmid", raw
    elif re.fullmatch(r"PMC\d+", raw, re.I):
        r["kind"], r["key"] = "pmcid", raw.upper()
    else:
        r["kind"], r["key"] = "doi", norm_doi(raw)

conv = {}
for kind in ("pmid", "pmcid", "doi"):
    keys = [r["key"] for r in inputs if r["kind"] == kind]
    if keys:
        res = idconv(keys, kind)
        conv.update({(kind, k.lower() if kind == "doi" else k): v for k, v in res.items()})

for r in inputs:
    c = conv.get((r["kind"], r["key"]), {})
    r["pmid"] = c.get("pmid") or (r["key"] if r["kind"] == "pmid" else None)
    r["pmcid"] = c.get("pmcid") or (r["key"] if r["kind"] == "pmcid" else None)
    r["doi"] = c.get("doi") or (r["key"] if r["kind"] == "doi" else None)
    r["resolved_via"] = "PMC ID Converter" if "error" not in c and c else None
    if not r["resolved_via"] and r["kind"] == "doi":
        p = pubmed_pmid_for_doi(r["key"])
        if p:
            r["pmid"], r["resolved_via"] = p, "PubMed esearch [doi] (not in PMC)"
    if not r["resolved_via"] and r["kind"] == "pmid":
        r["resolved_via"] = "PubMed (not in PMC)"

pm = pubmed_records(sorted({r["pmid"] for r in inputs if r["pmid"]}))
for r in inputs:
    m = pm.get(r["pmid"]) if r["pmid"] else None
    r["in_pubmed"] = bool(m)
    if m:
        if not r["doi"] and m["doi"]:
            r["doi"] = m["doi"]
        if not r["pmcid"] and m["pmcid"]:
            r["pmcid"] = m["pmcid"]

# ---- 2. dedupe on DOI, then PMID ----------------------------------------------------------------
merges, by_doi, by_pmid, uniques = [], {}, {}, []
for r in inputs:
    hit, why = None, None
    if r["doi"] and r["doi"] in by_doi:
        hit, why = by_doi[r["doi"]], "same DOI"
    elif r["pmid"] and r["pmid"] in by_pmid:
        hit, why = by_pmid[r["pmid"]], "same PMID"
    if hit:
        r["dup_of"] = hit["n"]
        merges.append({"input_n": r["n"], "input_id": r["input_id"], "merged_into_n": hit["n"],
                       "merged_into_id": hit["input_id"], "rule": why,
                       "key": r["doi"] if why == "same DOI" else r["pmid"]})
        continue
    r["dup_of"] = None
    uniques.append(r)
    if r["doi"]: by_doi[r["doi"]] = r
    if r["pmid"]: by_pmid[r["pmid"]] = r

# ---- 3. per unique article: metadata check, OA check, full text ---------------------------------
def nt(s):
    return " ".join(re.sub(r"[^a-z0-9 ]", " ", (s or "").lower()).split())


def journal_match(a_list, b_list):
    best = 0.0
    for a in filter(None, a_list):
        for b in filter(None, b_list):
            a2, b2 = nt(re.sub(r"\(.*?\)", "", a)).removeprefix("the "), nt(re.sub(r"\(.*?\)", "", b)).removeprefix("the ")
            s = 1.0 if (a2 == b2 or (len(a2) > 6 and (a2 in b2 or b2 in a2))) else SequenceMatcher(None, a2, b2).ratio()
            best = max(best, s)
    return round(best, 2)


epmc = europepmc(sorted({u["pmid"] for u in uniques if u["pmid"]}))
articles = []
for u in uniques:
    m = pm.get(u["pmid"], {}) if u["pmid"] else {}
    a = {"id": len(articles) + 1, "input_n": u["n"], "pmid": u["pmid"], "pmcid": u["pmcid"], "doi": u["doi"],
         "resolved_via": u["resolved_via"], "title": m.get("title"), "journal": m.get("journal"),
         "year": m.get("year"), "n_authors": m.get("n_authors"), "abstract_words": m.get("abstract_words", 0),
         "pub_types": m.get("pub_types", [])}
    # metadata cross-check against Crossref
    notes, ok = [], False
    cr = crossref(u["doi"]) if u["doi"] else None
    if not m:
        notes.append("no PubMed record")
    if not cr:
        notes.append("DOI not found in Crossref" if u["doi"] else "no DOI to check")
    if m and cr:
        ts = round(max(SequenceMatcher(None, nt(m["title"]), nt(cr["title"] + " " + cr["subtitle"])).ratio(),
                       SequenceMatcher(None, nt(m["title"]), nt(cr["title"])).ratio()), 3)
        years = {y for y in (cr["year_issued"], cr["year_print"], cr["year_online"]) if y}
        y_ok = m["year"] in years
        y_close = (not y_ok) and any(abs(m["year"] - y) <= 1 for y in years)
        js = journal_match([m["journal"], m["journal_abbrev"]], [cr["journal"], cr["journal_short"]])
        sub_only = ts < 0.9 and len(nt(cr["title"])) >= 30 and nt(m["title"]).startswith(nt(cr["title"]))
        if sub_only:
            notes.append(f"title match {ts}: same title, PubMed adds a subtitle Crossref lacks")
            ts_ok = True
        else:
            ts_ok = ts >= 0.9
            if not ts_ok: notes.append(f"title match {ts}")
        if not y_ok: notes.append(f"year PubMed {m['year']} vs Crossref {sorted(years)}" + (" (online vs print)" if y_close else ""))
        if js < 0.8: notes.append(f"journal '{m['journal']}' vs '{cr['journal']}' ({js})")
        ok = ts_ok and (y_ok or y_close) and js >= 0.8
        a["check"] = {"title_score": ts, "year_pubmed": m["year"], "years_crossref": sorted(years), "journal_score": js,
                      "crossref_journal": cr["journal"], "publisher": cr["publisher"]}
    a["metadata_ok"] = ok
    a["metadata_notes"] = "; ".join(notes)
    # open-access check
    e = epmc.get(u["pmid"], {}) if u["pmid"] else {}
    a["epmc_open_access"] = e.get("is_oa", False)
    a["epmc_license"] = e.get("license")
    if not a["pmcid"] and e.get("pmcid"):
        a["pmcid"] = e["pmcid"]
    a.update({"status": None, "license": None, "source": None, "sections": [], "tables": [], "n_refs": 0,
              "refs_with_doi": 0, "refs_with_pmid": 0, "ref_ids": [], "supplements": [], "reason": ""})
    a["access"] = ""
    if not m and not cr:
        a["status"], a["reason"], a["access"] = "not found", "ID not found in PubMed, PMC or Crossref", "unknown"
    elif a["pmcid"] and a["epmc_open_access"]:
        src, xml = fulltext_xml(a["pmcid"])
        if src:
            art = jats.load(xml)
            li = jats.license_info(art, a["epmc_license"])
            a["source"] = src
            a["license"] = li["license_label"] or "see licence text"
            a["access"] = "PMC Open Access subset"
            a["license_url"] = li["license_url"]
            a["sections"] = jats.sections(art)
            refs = jats.references(art)
            a["n_refs"] = len(refs)
            a["refs_with_doi"] = sum(1 for x in refs if x["doi"])
            a["refs_with_pmid"] = sum(1 for x in refs if x["pmid"])
            a["ref_ids"] = [x["doi"] or (f"PMID:{x['pmid']}" if x["pmid"] else None) for x in refs]
            a["supplements"] = jats.supplements(art, a["pmcid"])
            for k, t in enumerate(jats.tables(art), 1):
                meta = {"label": t["label"], "caption": t["caption"], "footnote": t["footnote"][:400]}
                if t["rows"] is None:
                    meta.update({"file": None, "n_rows": 0, "n_cols": 0, "note": t["note"]})
                else:
                    fn = f"{a['pmcid']}_table{k:02d}.csv"
                    with open(OUT / "tables" / fn, "w", newline="", encoding="utf-8") as f:
                        csv.writer(f).writerows(t["rows"])
                    meta.update({"file": fn, "n_rows": len(t["rows"]), "n_cols": len(t["rows"][0]) if t["rows"] else 0,
                                 "header_rows": t["header_rows"]})
                a["tables"].append(meta)
            a["status"] = "full text"
            if not a["sections"]:
                a["reason"] = "XML has no body sections"
        else:
            a["status"], a["reason"], a["access"] = "abstract only", f"Open access in Europe PMC but {xml}", "PMC Open Access subset"
    else:
        up = unpaywall(u["doi"]) if u["doi"] else None
        a["unpaywall"] = up
        lic = (a["epmc_license"] or (up or {}).get("best_license") or "")
        a["license"] = lic.upper() if lic else "none found"
        if a["pmcid"]:
            a["status"], a["access"] = "abstract only", "PMC free to read, no reuse licence"
            a["reason"] = (f"In PMC ({a['pmcid']}), free to read, but not in the PMC Open Access subset: "
                           "no reuse licence, so the full text is not bulk-collected")
        elif up and up.get("is_oa"):
            a["status"] = "abstract only"
            where = "a repository" + (f" ({up['best_repository']})" if up.get("best_repository") else "") if up["best_host"] == "repository" else "the publisher site"
            a["access"] = {"bronze": "publisher, free to read, no licence", "hybrid": "publisher, open licence",
                           "gold": "publisher, open licence", "green": "repository copy"}.get(up["oa_status"], up["oa_status"])
            a["reason"] = (f"No copy in PMC or Europe PMC. Unpaywall: {up['oa_status']} copy on {where}"
                           f"{' (' + up['best_license'] + ')' if up.get('best_license') else ', no licence stated'}. "
                           "Publisher and repository websites are not scraped here; collect through the publisher's TDM API "
                           "or the client's licence")
        else:
            a["status"], a["access"] = "not OA", "closed (paywalled)"
            a["reason"] = ("Paywalled: no copy in PMC or Europe PMC"
                           + (f"; Unpaywall: {up['oa_status']}" if up else "")
                           + ". Needs the client's own publisher TDM licence or API key")
    if a["status"] != "full text" and m:
        a["reason"] += f". Abstract kept from PubMed ({a['abstract_words']} words)" if a["abstract_words"] else ". No abstract in PubMed"
    a["n_tables"] = len(a["tables"])
    a["n_tables_csv"] = sum(1 for t in a["tables"] if t["file"])
    a["n_sections"] = sum(1 for x in a["sections"] if x["kind"] == "main")
    a["n_supplements"] = len(a["supplements"])
    a["fulltext_words"] = sum(x["words"] for x in a["sections"] if x["kind"] == "main")
    u["article"] = a
    articles.append(a)

# ---- 4. coverage report: one row per input ID ---------------------------------------------------
by_n = {r["n"]: r for r in inputs}
cov = []
for r in inputs:
    a = r["article"] if r["dup_of"] is None else by_n[r["dup_of"]]["article"]
    cov.append({"n": r["n"], "input_id": r["input_id"], "input_type": r["kind"], "note": r["note"],
                "article_id": a["id"], "duplicate_of_input": r["dup_of"] or "",
                "status": "duplicate (merged)" if r["dup_of"] else a["status"],
                "pmid": a["pmid"] or "", "pmcid": a["pmcid"] or "", "doi": a["doi"] or "",
                "title": a["title"] or "", "journal": a["journal"] or "", "year": a["year"] or "",
                "license": a["license"] or "", "access_route": a["access"], "metadata_ok": a["metadata_ok"], "metadata_notes": a["metadata_notes"],
                "n_sections": a["n_sections"], "n_tables": a["n_tables"], "n_tables_csv": a["n_tables_csv"],
                "n_refs": a["n_refs"], "refs_with_doi": a["refs_with_doi"], "refs_with_pmid": a["refs_with_pmid"],
                "n_supplements": a["n_supplements"], "source": a["source"] or "",
                "reason": (f"Same article as input #{r['dup_of']} ({next(x['rule'] for x in merges if x['input_n'] == r['n'])}); "
                           f"counted once") if r["dup_of"] else a["reason"]})

with open(OUT / "coverage.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(cov[0])); w.writeheader(); w.writerows(cov)
with open(OUT / "tables_index.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["pmcid", "pmid", "doi", "journal", "year", "license", "label", "caption", "file", "n_rows", "n_cols", "note"])
    for a in articles:
        for t in a["tables"]:
            w.writerow([a["pmcid"], a["pmid"], a["doi"], a["journal"], a["year"], a["license"], t["label"], t["caption"],
                        t["file"] or "", t["n_rows"], t["n_cols"], t.get("note", "")])
with zipfile.ZipFile(OUT / "tables.zip", "w", zipfile.ZIP_DEFLATED) as z:
    z.write(OUT / "tables_index.csv", "tables_index.csv")
    for p in sorted((OUT / "tables").glob("*.csv")):
        z.write(p, f"tables/{p.name}")

statuses = [a["status"] for a in articles]
summary = {
    "run_date": datetime.date.today().isoformat(), "query": query,
    "inputs": len(inputs), "unique": len(articles), "duplicates_merged": len(merges),
    "full_text": statuses.count("full text"), "abstract_only": statuses.count("abstract only"),
    "not_oa": statuses.count("not OA"), "not_found": statuses.count("not found"),
    "tables": sum(a["n_tables"] for a in articles), "tables_csv": sum(a["n_tables_csv"] for a in articles),
    "references": sum(a["n_refs"] for a in articles), "refs_with_doi": sum(a["refs_with_doi"] for a in articles),
    "refs_with_pmid": sum(a["refs_with_pmid"] for a in articles),
    "supplements": sum(a["n_supplements"] for a in articles), "sections": sum(a["n_sections"] for a in articles),
    "metadata_ok": sum(1 for a in articles if a["metadata_ok"]),
    "coverage_rows": len(cov), "every_input_has_row": len(cov) == len(inputs),
    "api_calls_network": polite.STATS["network"], "api_calls_cached": polite.STATS["cached"],
}
(OUT / "articles.json").write_text(json.dumps({"summary": summary, "merges": merges, "articles": articles}, indent=1, ensure_ascii=False))
(OUT / "coverage.json").write_text(json.dumps(cov, ensure_ascii=False))
print(json.dumps(summary, indent=1))
for x in merges:
    print("MERGE", x)
