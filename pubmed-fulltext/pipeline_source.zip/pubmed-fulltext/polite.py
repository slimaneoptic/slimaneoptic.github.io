"""Polite HTTP helper: fixed User-Agent, per-host minimum interval, on-disk cache, retries."""
import hashlib, json, time, pathlib
from urllib.parse import urlparse
import requests

TOOL = "slimanechanchoul-demo"
EMAIL = "demo@slimanechanchoul.com"   # generic contact address for API etiquette
UA = f"{TOOL}/1.0 (+https://slimanechanchoul.com/pubmed-fulltext/; mailto:{EMAIL})"
CACHE = pathlib.Path(__file__).parent / "data" / "cache"
CACHE.mkdir(parents=True, exist_ok=True)

# seconds between calls per host (NCBI: max 3 requests/s without an API key -> 0.4 s)
MIN_GAP = {"eutils.ncbi.nlm.nih.gov": 0.4, "pmc.ncbi.nlm.nih.gov": 0.4,
           "www.ebi.ac.uk": 0.25, "api.crossref.org": 0.25, "api.unpaywall.org": 0.25}
_last = {}
_s = requests.Session()
_s.headers["User-Agent"] = UA
STATS = {"network": 0, "cached": 0}


def get(url, params=None, data=None, timeout=40):
    """Return (status_code, text). Cached by URL+params+body so re-runs do not hit the APIs again."""
    key = hashlib.sha1(json.dumps([url, params, data], sort_keys=True).encode()).hexdigest()
    f = CACHE / f"{key}.json"
    if f.exists():
        STATS["cached"] += 1
        d = json.loads(f.read_text())
        return d["status"], d["text"]
    host = urlparse(url).netloc
    for attempt in range(4):
        gap = MIN_GAP.get(host, 0.3) - (time.time() - _last.get(host, 0))
        if gap > 0:
            time.sleep(gap)
        _last[host] = time.time()
        try:
            r = _s.post(url, data=data, params=params, timeout=timeout) if data else _s.get(url, params=params, timeout=timeout)
        except requests.RequestException:
            time.sleep(2 * (attempt + 1)); continue
        STATS["network"] += 1
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(3 * (attempt + 1)); continue
        if r.status_code in (200, 404, 400):
            f.write_text(json.dumps({"status": r.status_code, "text": r.text}))
        return r.status_code, r.text
    return 0, ""
