"""Build the input list from one public PubMed query:
40 PMIDs + 5 DOIs with no PMC copy (checked closed in Unpaywall) + 2 deliberate duplicates (PMID also given as DOI)."""
import csv, json, pathlib
from polite import get, TOOL, EMAIL
from sources import idconv, pubmed_records, unpaywall

HERE = pathlib.Path(__file__).parent
QUERY = 'SGLT2 inhibitors heart failure AND randomized controlled trial[pt]'
MINDATE, MAXDATE = "2020", "2024"

st, txt = get("https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
              params={"db": "pubmed", "term": QUERY, "mindate": MINDATE, "maxdate": MAXDATE, "datetype": "pdat",
                      "retmax": 120, "sort": "relevance", "retmode": "json", "tool": TOOL, "email": EMAIL})
res = json.loads(txt)["esearchresult"]
pmids = res["idlist"]
print("query hits:", res["count"], "taken:", len(pmids))
conv = idconv(pmids, "pmid")
meta = pubmed_records(pmids)

main = pmids[:40]
extra = []
for p in pmids[40:]:
    m = meta.get(p, {})
    if conv.get(p, {}).get("pmcid") or not m.get("doi"):
        continue
    up = unpaywall(m["doi"])
    if up and up.get("is_oa") is False:
        extra.append((m["doi"], p))
    if len(extra) == 5:
        break

with_pmc = [p for p in main if conv.get(p, {}).get("pmcid") and meta.get(p, {}).get("doi")]
without_pmc = [p for p in main if not conv.get(p, {}).get("pmcid") and meta.get(p, {}).get("doi")]
dup1, dup2 = with_pmc[0], without_pmc[0]

rows = [{"input_id": p, "id_type": "pmid", "note": f"query result #{i+1}"} for i, p in enumerate(main)]
rows += [{"input_id": d, "id_type": "doi", "note": f"query result, no PMC copy, Unpaywall closed (PMID {p})"} for d, p in extra]
rows.append({"input_id": meta[dup1]["doi"], "id_type": "doi", "note": f"deliberate duplicate of PMID {dup1}"})
rows.append({"input_id": "https://doi.org/" + meta[dup2]["doi"].upper(), "id_type": "doi",
             "note": f"deliberate duplicate of PMID {dup2} (doi.org URL, upper case)"})
with open(HERE / "inputs.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["input_id", "id_type", "note"]); w.writeheader(); w.writerows(rows)
(HERE / "query.json").write_text(json.dumps({"query": QUERY, "mindate": MINDATE, "maxdate": MAXDATE, "sort": "relevance",
                                             "hits": int(res["count"]), "retrieved": len(pmids)}, indent=1))
print(len(rows), "inputs written")
