"""Drives the live API over HTTP and saves every request/response to demo-run/*.json (secrets redacted).
    OMS_URL=http://127.0.0.1:8077 OMS_USER=sample.staff OMS_PASSWORD=... python -m scripts.walkthrough"""
import json
import os
from pathlib import Path

import httpx

BASE = os.environ.get("OMS_URL", "http://127.0.0.1:8077")
OUT = Path(__file__).resolve().parent.parent / "demo-run"
OUT.mkdir(exist_ok=True)
SAMPLES = OUT.parent / "samples"
SAMPLES.mkdir(exist_ok=True)
n = 0
token = ""


def save(name, method, path, body, resp, note="", form=False, raw_note=None):
    global n
    n += 1
    req_body = body
    if form:
        req_body = {"username": body["username"], "password": "<redacted>"}
    try:
        rb = resp.json()
    except Exception:
        rb = raw_note or f"<{resp.headers.get('content-type')}, {len(resp.content)} bytes>"
    if isinstance(rb, dict) and "access_token" in rb:
        rb = {**rb, "access_token": "<jwt, shortened>"}
    doc = {"step": n, "title": note, "request": {"method": method, "path": path,
           "headers": ({"Authorization": "Bearer <jwt>"} if token and not form else {}), "body": req_body},
           "response": {"status": resp.status_code, "body": rb}}
    (OUT / f"{n:02d}-{name}.json").write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n")
    return rb


def call(c, name, method, path, body=None, note="", **kw):
    h = {"Authorization": f"Bearer {token}"} if token else {}
    r = c.request(method, path, json=body, headers=h, **kw)
    return r, save(name, method, path, body, r, note)


with httpx.Client(base_url=BASE, timeout=30) as c:
    form = {"username": os.environ["OMS_USER"], "password": os.environ["OMS_PASSWORD"]}
    r = c.post("/auth/token", data=form)
    save("login", "POST", "/auth/token", form, r, "Log in (OAuth2 password flow)", form=True)
    token = r.json()["access_token"]

    r, cust = call(c, "create-customer", "POST", "/customers", {
        "name": "Sample Walkthrough Trading Co.", "tax_id": "91310000SAMPLE0WALK", "address": "Sample Road 8, Shanghai",
        "is_export": False}, "Create a customer")
    r, order = call(c, "create-order", "POST", "/orders", {
        "customer_id": cust["id"], "order_date": "2026-11-24", "price_mode": "inclusive", "discount": "200.00",
        "notes": "Walkthrough order", "lines": [
            {"description": "Steel bolts M8 (box of 500)", "quantity": "50", "unit_price": "128.00", "tax_category": "standard"},
            {"description": "Rice, 25 kg bag", "quantity": "40", "unit_price": "118.00", "tax_category": "reduced"}]},
        "Create an order with tax-inclusive prices and a 200.00 order discount")
    oid = order["id"]
    call(c, "illegal-move", "POST", f"/orders/{oid}/status", {"status": "shipped"}, "Try an illegal move (draft -> shipped)")
    call(c, "confirm", "POST", f"/orders/{oid}/status", {"status": "confirmed"}, "Confirm the order")
    r, pay = call(c, "payment", "POST", f"/orders/{oid}/payments", {
        "amount": "5000.00", "method": "bank_transfer", "reference": "BANK-DEMO-0001", "paid_at": "2026-11-24T14:00:00+08:00"},
        "Record a partial payment")
    call(c, "refund-too-large", "POST", f"/payments/{pay['id']}/refunds", {"amount": "5000.01"}, "Try to refund more than was paid")
    r, ref = call(c, "refund", "POST", f"/payments/{pay['id']}/refunds", {
        "amount": "500.00", "reason": "Two damaged bags", "credit_note_no": "CN-DEMO-0001",
        "refunded_at": "2026-11-24T16:00:00+08:00"}, "Refund part of the payment")
    call(c, "order-after", "GET", f"/orders/{oid}", None, "The order now")
    call(c, "monthly-report", "GET", "/reports/summary?year=2026&period=month", None, "Monthly summary for 2026")
    r = c.get("/reports/export.xlsx", params={"year": 2026}, headers={"Authorization": f"Bearer {token}"})
    save("excel-export", "GET", "/reports/export.xlsx?year=2026", None, r, "Excel export")
    (SAMPLES / "report-2026.xlsx").write_bytes(r.content)
    r = c.get("/reports/export.csv", params={"year": 2026, "kind": "transactions"}, headers={"Authorization": f"Bearer {token}"})
    (SAMPLES / "transactions-2026.csv").write_bytes(r.content)
print("saved", n, "steps")
