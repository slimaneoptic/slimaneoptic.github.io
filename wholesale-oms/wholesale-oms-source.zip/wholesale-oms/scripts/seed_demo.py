"""Fictional sample data, July-November 2026. Run after `init-db` and `create-admin`:
    python -m scripts.seed_demo
Goes through the same service layer as the API, so totals, snapshots and the audit log are real."""
import random
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from sqlalchemy import select

from app import schemas, services
from app.db import SessionLocal
from app.models import Customer, Order, Product, User
from app.security import hash_password

D = Decimal
CUSTOMERS = [
    ("Sample Trading Co. A", "91310000SAMPLE001A", "Unit 1, Sample Road, Shanghai", False),
    ("Sample Trading Co. B", "91440300SAMPLE002B", "Unit 2, Sample Avenue, Shenzhen", False),
    ("Sample Retail Group", "91330100SAMPLE003C", "Sample Plaza, Hangzhou", False),
    ("Sample Foods Wholesale", "91320500SAMPLE004D", "Sample Market, Suzhou", False),
    ("Sample Hardware Supply", "91510100SAMPLE005E", "Sample Park, Chengdu", False),
    ("Sample Export Ltd", None, "Sample Harbour, Singapore", True),
]
PRODUCTS = [  # sku, name, unit, category, price
    ("BLT-M8", "Steel bolts M8 (box of 500)", "box", "standard", "128.00"),
    ("TSH-12", "Cotton T-shirts, plain (dozen)", "dozen", "standard", "360.00"),
    ("LED-36", "LED panel light 36W", "pcs", "standard", "58.50"),
    ("CHR-01", "Office chair", "pcs", "standard", "299.00"),
    ("APL-10", "Fresh apples, 10 kg carton", "carton", "reduced", "85.00"),
    ("RIC-25", "Rice, 25 kg bag", "bag", "reduced", "118.00"),
    ("BKS-20", "Printed books (carton of 20)", "carton", "reduced", "640.00"),
    ("SRV-PK", "Packing and labelling service", "job", "service", "1200.00"),
    ("SRV-DL", "Local delivery service", "trip", "service", "450.00"),
]
LAST_PAY_DAY = date(2026, 11, 23)


def at(d: date, hour=10) -> datetime:
    return datetime.combine(d, time(hour, 0))  # naive = business timezone (Asia/Shanghai)


def main() -> None:
    rng = random.Random(2026)
    with SessionLocal() as db:
        admin = db.scalar(select(User).where(User.role == "admin"))
        if admin is None:
            raise SystemExit("Create an admin first: python -m app.cli create-admin <username>")
        if db.scalar(select(Order.id).limit(1)):
            raise SystemExit("Orders already exist; seed only on an empty database.")
        staff = db.scalar(select(User).where(User.username == "sample.staff"))
        if staff is None:
            import os
            if not os.environ.get("OMS_STAFF_PASSWORD"):
                raise SystemExit("Set OMS_STAFF_PASSWORD (min 10 chars) for the sample staff user.")
            staff = User(username="sample.staff", full_name="Sample Staff", role="staff",
                         password_hash=hash_password(os.environ["OMS_STAFF_PASSWORD"]))
            db.add(staff)
            db.commit()
        custs = []
        for name, tax_id, addr, exp in CUSTOMERS:
            c = Customer(name=name, tax_id=tax_id, address=addr, is_export=exp)
            db.add(c)
            custs.append(c)
        prods = [Product(sku=s, name=n, unit=u, tax_category=c, default_price=D(p)) for s, n, u, c, p in PRODUCTS]
        db.add_all(prods)
        db.commit()

        months = [(2026, 7), (2026, 8), (2026, 9), (2026, 10), (2026, 11)]
        n_orders = 0
        for (y, m) in months:
            last = 24 if m == 11 else 28
            for i in range(rng.randint(5, 7)):
                cust = custs[-1] if i == 2 else rng.choice(custs[:-1])
                od = date(y, m, rng.randint(1, last))
                mode = rng.choice(["inclusive", "inclusive", "exclusive"])
                lines = []
                for _ in range(rng.randint(1, 4)):
                    p = rng.choice(prods)
                    qty = D(rng.choice([5, 10, 20, 50, 100, 120, 200]))
                    ld = D(rng.choice(["0", "0", "0", "25.00", "60.00"]))
                    lines.append(schemas.LineIn(product_id=p.id, quantity=qty, unit_price=p.default_price,
                                                line_discount=min(ld, qty * p.default_price)))
                subtotal = sum(l.quantity * l.unit_price - l.line_discount for l in lines)
                od_disc = D(rng.choice(["0", "0", "50.00", "120.00", "300.00"]))
                if od_disc > subtotal:
                    od_disc = D("0")
                o = services.create_order(db, admin, schemas.OrderCreate(
                    customer_id=cust.id, order_date=od, price_mode=mode, discount=od_disc,
                    notes="Sample order", lines=lines))
                n_orders += 1
                age = (date(2026, 11, 24) - od).days
                path = ["confirmed"]
                if age > 10:
                    path.append("shipped")
                if age > 25:
                    path.append("completed")
                if rng.random() < 0.07 and age > 5:
                    path = ["cancelled"]
                for s in path:
                    services.transition(db, staff, o, s)
                if o.status == "cancelled":
                    continue
                if o.status in ("shipped", "completed") and o.price_mode == "inclusive":
                    o.fapiao_no = f"FP-{o.id:08d}"
                    db.commit()
                # payments: most orders get a full or part payment
                roll = rng.random()
                pay_day = min(od + timedelta(days=rng.randint(3, 20)), LAST_PAY_DAY)
                pays = []
                if roll < 0.55:
                    pays = [o.gross_total]
                elif roll < 0.85:
                    first = (o.gross_total * D("0.5")).quantize(D("0.01"))
                    pays = [first] if age < 25 else [first, o.gross_total - first]
                for k, amt in enumerate(pays):
                    d = min(pay_day + timedelta(days=15 * k), LAST_PAY_DAY)
                    if d < od:
                        d = od
                    pay = services.add_payment(db, staff, o, schemas.PaymentIn(
                        amount=amt, method=rng.choice(["bank_transfer", "bank_transfer", "alipay"]),
                        reference=f"BANK-{rng.randint(100000, 999999)}", paid_at=at(d)))
                    if k == 0 and len(pays) == 1 and o.status in ("shipped", "completed") and rng.random() < 0.3:
                        ramt = (amt * D(rng.choice(["0.1", "0.25"]))).quantize(D("0.01"))
                        rd = min(d + timedelta(days=rng.randint(2, 12)), LAST_PAY_DAY)
                        services.add_refund(db, staff, pay.id, schemas.RefundIn(
                            amount=ramt, reason="Returned goods, partial credit", credit_note_no=f"CN-{o.id:06d}",
                            refunded_at=at(rd, 15)))
        # one draft order that is still being built
        services.create_order(db, staff, schemas.OrderCreate(
            customer_id=custs[0].id, order_date=date(2026, 11, 24), notes="Quote not confirmed yet",
            lines=[schemas.LineIn(product_id=prods[0].id, quantity=D("40"), unit_price=prods[0].default_price)]))
        print(f"Seeded {len(custs)} customers, {len(prods)} products, {n_orders + 1} orders.")


if __name__ == "__main__":
    main()
