"""Builds the static demo pages from REAL artefacts (demo-run/*.json, openapi.json, test-results.json):
    python -m scripts.build_site <output_dir>
Every number on the page is read from those files; nothing is typed in by hand."""
import html
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(sys.argv[1])
run = {p.name.split("-", 1)[1][:-5]: json.loads(p.read_text()) for p in sorted((ROOT / "demo-run").glob("*.json"))}
spec = json.loads((ROOT / "openapi.json").read_text())
tests = json.loads((ROOT / "test-results.json").read_text())
e = html.escape

ADMIN_ONLY = lambda path, m: path.startswith("/users") or path == "/audit-log" or (path == "/settings" and m == "put") or \
    (path.startswith("/tax-rates") and m in ("post", "patch"))
PUBLIC = {("/auth/token", "post"), ("/health", "get")}

HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta name="robots" content="noindex">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Overpass:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root { --surface:#fff; --btnbg:#14202B; --btnfg:#fff; --btnhover:#22364a; --ink:#14202B; --paper:#F6F8FA; --slate:#5B6B7A; --rule:#D5DBE1; --blue:#2A78D6; --bar:3.25rem; --code:#0f1b26; --codefg:#dbe7f3; }
* { box-sizing: border-box; }
html, body { margin:0; background:var(--paper); color:var(--ink); font-family:"Overpass", system-ui, sans-serif; line-height:1.55; }
.bar { height:var(--bar); display:flex; align-items:center; justify-content:space-between; gap:1rem; padding:0 1.25rem; border-bottom:1px solid var(--rule); background:var(--paper); }
.demo { color:var(--slate); font-weight:600; }
.links a { color:var(--ink); text-decoration:none; font-size:.95rem; margin-left:1.2rem; } .links a:hover { color:var(--blue); }
.btn { background:var(--btnbg); color:var(--btnfg) !important; padding:.45rem .85rem .35rem; border-radius:7px; font-weight:600; text-decoration:none; display:inline-block; font-size:.92rem; }
.btn:hover { background:var(--btnhover); } .btn.alt { background:var(--surface); color:var(--ink) !important; border:1px solid var(--ink); }
a:focus-visible, summary:focus-visible { outline:3px solid var(--blue); outline-offset:3px; border-radius:4px; }
main { max-width:1040px; margin:0 auto; padding:2rem 1rem 3rem; }
h1 { font-size:clamp(1.6rem,4vw,2.3rem); line-height:1.15; margin:0 0 .5rem; }
h2 { font-size:1.2rem; margin:2.4rem 0 .7rem; }
.lead { color:var(--slate); font-size:1.1rem; margin:0 0 1.2rem; max-width:46rem; }
.actions { display:flex; flex-wrap:wrap; gap:.6rem; margin:0 0 1.2rem; }
table.t { border-collapse:collapse; width:100%; background:var(--surface); font-size:.92rem; }
.t td,.t th { padding:.45rem .6rem; border-bottom:1px solid var(--rule); text-align:left; vertical-align:top; } .t th { color:var(--slate); font-weight:600; }
td.n,th.n { text-align:right; font-variant-numeric:tabular-nums; }
.scroll { overflow-x:auto; border:1px solid var(--rule); border-radius:8px; background:var(--surface); }
.kpi { display:grid; grid-template-columns:repeat(4,1fr); gap:.8rem; margin:1rem 0; }
.kpi div { background:var(--surface); border:1px solid var(--rule); border-radius:8px; padding:.7rem; font-size:.88rem; color:var(--slate); } .kpi b { display:block; font-size:1.35rem; color:var(--ink); }
.step { background:var(--surface); border:1px solid var(--rule); border-radius:8px; padding:.9rem 1rem; margin:0 0 .9rem; }
.step h3 { margin:0 0 .3rem; font-size:1.02rem; } .step p { margin:.3rem 0; color:var(--slate); font-size:.93rem; }
.step .num { display:inline-block; background:var(--ink); color:#fff; border-radius:50%; width:1.5rem; height:1.5rem; text-align:center; line-height:1.5rem; font-size:.85rem; margin-right:.4rem; }
details { margin:.5rem 0 0; } summary { cursor:pointer; color:var(--blue); font-size:.9rem; }
pre { background:var(--code); color:var(--codefg); padding:.8rem; border-radius:7px; overflow-x:auto; font-size:.8rem; line-height:1.45; margin:.4rem 0; }
.tag { display:inline-block; font-size:.78rem; font-weight:600; padding:.05rem .45rem; border-radius:5px; background:#e8eef5; color:var(--ink); }
.note { color:var(--slate); font-size:.88rem; }
ul { padding-left:1.2rem; margin:0; } li { margin:.3rem 0; }
.small { color:var(--slate); font-size:.85rem; margin-top:2.5rem; }
@media (max-width:760px) { .kpi { grid-template-columns:1fr 1fr; } }
@media (max-width:520px) { .demo { display:none; } }
</style>
<link rel="stylesheet" href="/theme.css">
<script src="/theme.js"></script>
<script defer src="/hit.js"></script>
</head>
<body>
<header class="bar">
  <span class="demo">Wholesale order and VAT reporting demo</span>
  <nav class="links" aria-label="Site"><a href="/#demos">All work</a></nav>
</header>
<main>
"""
FOOT = "\n</main>\n</body></html>\n"


def pj(obj):
    return e(json.dumps(obj, indent=2, ensure_ascii=False))


def trim_order(b):
    keep = ("number", "status", "payment_status", "price_mode", "currency", "order_date", "discount", "list_total",
            "discount_total", "net_total", "tax_total", "gross_total", "paid_total", "refunded_total", "balance_due")
    out = {k: b[k] for k in keep if k in b}
    out["lines"] = [{k: ln[k] for k in ("description", "quantity", "unit_price", "tax_rate", "list_amount",
                                         "order_discount_alloc", "net_amount", "tax_amount", "gross_amount")} for ln in b["lines"]]
    return out


def step_block(n, title, text, name, req_body=True, resp_trim=None, extra=""):
    d = run[name]
    rq, rs = d["request"], d["response"]
    body = resp_trim(rs["body"]) if resp_trim else rs["body"]
    req = {"request": f'{rq["method"]} {rq["path"]}', **({"body": rq["body"]} if req_body and rq["body"] else {})}
    return (f'<div class="step"><h3><span class="num">{n}</span>{e(title)}</h3><p>{text}</p>{extra}'
            f'<details><summary>Show the request and response ({rs["status"]})</summary><pre>{pj(req)}</pre>'
            f'<pre>{pj({"status": rs["status"], "body": body})}</pre></details></div>')


# ---------------- numbers from the run ----------------
order = run["create-order"]["response"]["body"]
l1, l2 = order["lines"]
conf = run["confirm"]["response"]["body"]
pay = run["payment"]["response"]["body"]
ref = run["refund"]["response"]["body"]
after = run["order-after"]["response"]["body"]
bad_move = run["illegal-move"]["response"]["body"]["detail"]
bad_ref = run["refund-too-large"]["response"]["body"]["detail"]
months = run["monthly-report"]["response"]["body"]
nov = next(r for r in months if r["period"] == "2026-11")
import re as _re
xl = _re.search(r"(\d+) bytes", run["excel-export"]["response"]["body"])[1] + " bytes"

split = f"""<div class="scroll"><table class="t"><thead><tr><th>Line</th><th>Price you quote</th><th class="n">Order discount share</th><th class="n">Paid by customer</th><th class="n">Rate</th><th class="n">Net sale</th><th class="n">VAT</th></tr></thead><tbody>
<tr><td>{e(l1['description'])}</td><td>{l1['quantity']} x {l1['unit_price']} = {l1['list_amount']}</td><td class="n">-{l1['order_discount_alloc']}</td><td class="n">{l1['gross_amount']}</td><td class="n">{float(l1['tax_rate'])*100:.0f}%</td><td class="n">{l1['net_amount']}</td><td class="n">{l1['tax_amount']}</td></tr>
<tr><td>{e(l2['description'])}</td><td>{l2['quantity']} x {l2['unit_price']} = {l2['list_amount']}</td><td class="n">-{l2['order_discount_alloc']}</td><td class="n">{l2['gross_amount']}</td><td class="n">{float(l2['tax_rate'])*100:.0f}%</td><td class="n">{l2['net_amount']}</td><td class="n">{l2['tax_amount']}</td></tr>
<tr><td><b>Order</b></td><td>{order['list_total']} less {order['discount']} discount</td><td class="n"></td><td class="n"><b>{order['gross_total']}</b></td><td></td><td class="n"><b>{order['net_total']}</b></td><td class="n"><b>{order['tax_total']}</b></td></tr></tbody></table></div>"""

steps = "".join([
    step_block(1, "Log in", "Standard username and password login. The token goes into every later call. The saved copy hides the real token and password.", "login"),
    step_block(2, "Create a customer", "A domestic customer. Export customers are flagged <code>is_export</code> and are zero-rated automatically.", "create-customer"),
    step_block(3, "Create an order with tax-inclusive prices and a discount",
               f"Prices are quoted with VAT included. The {order['discount']} discount is spread over the two lines by value, and each paid amount is split into net and VAT at that line's rate. "
               f"The order is {order['gross_total']} = {order['net_total']} net + {order['tax_total']} VAT.", "create-order", resp_trim=trim_order, extra=split),
    step_block(4, "Workflow rules are enforced", f"Skipping a step is refused with a plain message: <i>{e(bad_move)}</i> Then the order is confirmed (status now <b>{conf['status']}</b>); from here its lines are locked.", "confirm"),
    step_block(5, "Record a partial payment", f"{pay['amount']} received by bank transfer against an order of {order['gross_total']}.", "payment"),
    step_block(6, "Refund part of it", f"A refund of {ref['amount']} linked to that payment carries {ref['vat_amount']} of VAT and {ref['net_amount']} net, in proportion to the order's VAT share. "
               f"Trying to refund more than was paid is refused: <i>{e(bad_ref)}</i> The order afterwards is <b>{after['payment_status']}</b>: paid {after['paid_total']}, refunded {after['refunded_total']}, still due {after['balance_due']}.",
               "refund"),
    step_block(7, "Monthly report and Excel export", f"November 2026 in the monthly summary: {nov['orders']} orders, net sales {nov['net_sales']}, output VAT {nov['output_vat']}, refunds credited {nov['refunds_vat']} VAT, "
               f"VAT after refunds {nov['vat_after_refunds']}, payments received {nov['payments_received']}. The same data downloads as an Excel workbook ({xl}). The sample files below were produced this way.",
               "monthly-report", req_body=False,
               resp_trim=lambda b: [next(r for r in b if r["period"] == "2026-11")]),
])

rates_rows = [
    ("General taxpayer", "Goods (standard)", "13%", "from 2026-01-01"),
    ("General taxpayer", "Reduced-rate goods (e.g. agricultural products, books)", "9%", "from 2026-01-01"),
    ("General taxpayer", "Services", "6%", "from 2026-01-01"),
    ("General taxpayer", "Exports (zero-rated)", "0%", "from 2026-01-01"),
    ("Small-scale taxpayer", "Levy rate, all domestic categories", "3%", "from 2026-01-01 (applies again after 2027-12-31)"),
    ("Small-scale taxpayer", "Preferential rate", "1%", "2026-01-01 to 2027-12-31"),
]
rates_html = "".join(f"<tr><td>{a}</td><td>{b}</td><td class='n'>{c}</td><td>{d}</td></tr>" for a, b, c, d in rates_rows)

month_rows = "".join(
    f"<tr><td>{r['period']}</td><td class='n'>{r['orders']}</td><td class='n'>{r['net_sales']}</td><td class='n'>{r['output_vat']}</td>"
    f"<td class='n'>{r['refunds_vat']}</td><td class='n'>{r['payments_received']}</td><td class='n'>{r['outstanding_receivables']}</td></tr>"
    for r in months if r["period_type"] == "month" and r["orders"])
q_rows = "".join(
    f"<tr><td>{r['period']}</td><td class='n'>{r['orders']}</td><td class='n'>{r['net_sales']}</td><td class='n'>{r['output_vat']}</td>"
    f"<td class='n'>{r['refunds_vat']}</td><td class='n'>{r['payments_received']}</td><td class='n'>{r['outstanding_receivables']}</td></tr>"
    for r in months if r["period_type"] == "quarter" and r["orders"])
rep_head = "<thead><tr><th>Period</th><th class='n'>Orders</th><th class='n'>Net sales</th><th class='n'>Output VAT</th><th class='n'>Refund VAT credited</th><th class='n'>Payments received</th><th class='n'>Outstanding</th></tr></thead>"

index = HEAD.replace("{title}", "Wholesale order and VAT reporting demo").replace("{desc}",
                    "A working order management and VAT reporting backend (FastAPI + MySQL): orders, payments, refunds, monthly and quarterly reports, Excel and CSV export.") + f"""
<h1>Wholesale orders, payments and VAT reports</h1>
<p class="lead">A working backend (Python, FastAPI, MySQL 8.4) that takes wholesale orders, tracks payments and refunds, works out the VAT on every line, and gives you monthly and quarterly reports as Excel or CSV.</p>
<div class="kpi"><div>Automated tests, all passing<b>{tests['passed']}</b></div><div>API endpoints<b>{sum(len(v) for v in spec['paths'].values())}</b></div><div>Report formats<b>Excel + CSV</b></div><div>Database<b>MySQL {tests['mysql']}</b></div></div>
<div class="actions"><a class="btn" href="report-2026.xlsx">Sample Excel report</a><a class="btn alt" href="transactions-2026.csv">Transactions CSV</a><a class="btn alt" href="api.html">API reference</a><a class="btn alt" href="schema.sql">Database schema</a><a class="btn alt" href="wholesale-oms-source.zip">Source code (.zip)</a></div>
<p class="note">Everything below was produced by running the real code against a real MySQL database. The customers and orders are fictional sample data.</p>

<h2>A real run, step by step</h2>
<p>These are the actual calls and answers from one run, in order. Open "Show the request and response" on any step if you want the raw JSON.</p>
{steps}

<h2>How the VAT is decided</h2>
<p>The rate is looked up from a table by taxpayer type, product category and the <b>order date</b>, then stored on each order line. If a rate changes later, old orders do not change. Another country is a set of new rows in that table, not new code.</p>
<div class="scroll"><table class="t"><thead><tr><th>Taxpayer</th><th>What</th><th class="n">Rate</th><th>Valid</th></tr></thead><tbody>{rates_html}</tbody></table></div>
<p class="note">China VAT preset, per 2026 VAT Law summaries; confirm with your accountant. The business taxpayer type (general or small-scale) is a setting. Amounts round half-up to 0.01 per line; for tax-inclusive prices net = gross / (1 + rate) and VAT = gross - net, so the pieces always add up exactly.</p>

<h2>What the reports look like</h2>
<p>From the fictional sample orders (July to November 2026, CNY, tax-inclusive and tax-exclusive prices, discounts, one export customer, part payments and refunds). Refund VAT is credited in the month of the refund.</p>
<div class="scroll"><table class="t">{rep_head}<tbody>{month_rows}{q_rows}</tbody></table></div>
<p class="note">The Excel file has four sheets: Summary, By rate, By customer and Transactions (every order line, payment and refund with date, customer, rate, net and VAT). Header row frozen, number formats and column widths set.</p>

<h2>Tests</h2>
<p><b>{tests['passed']} passed, {tests['failed']} failed</b> in {tests['seconds']} s, run on {tests['date']} against a real MySQL {tests['mysql']} container (not a stand-in database).</p>
<ul>
<li>Rounding: tax-inclusive and tax-exclusive, half-up, net + VAT always equal to the total</li>
<li>Mixed rates in one order; order discount spread exactly over the lines; discounts reduce the taxable amount</li>
<li>Zero-rated export; rate effective dates (small-scale 1% on 2027-12-31, 3% on 2028-01-01); old orders keep their rate when a rate changes</li>
<li>Order workflow including refused moves; locked lines after confirmation; payment statuses; refunds cannot exceed the payment</li>
<li>Report totals equal the sum of the ledger and the order totals; months and quarters add up to the year; CSV and Excel structure</li>
<li>Logins, wrong passwords, deactivated users, admin versus staff permissions, audit trail</li>
<li>Adding another country's tax rates as data only</li>
</ul>

<h2>Also included</h2>
<ul>
<li>Admin and staff roles; admin manages users, tax rates and settings; every change to orders, payments, refunds and rates is written to an audit log with old and new values.</li>
<li>Filters and pages on every list (status, customer, date range).</li>
<li>Invoice (fapiao) number on orders and a credit-note reference on refunds, as plain fields.</li>
<li>Docker Compose file for MySQL and the app, setup and test instructions in the README (inside the zip).</li>
</ul>

<h2>Not covered, honestly</h2>
<ul>
<li>No link to the Golden Tax system or e-invoicing: invoice numbers are just stored.</li>
<li>Output VAT only: no input VAT deduction, withholding or local surcharges.</li>
<li>The rates are a starting preset, not tax advice.</li>
<li>One currency per order, no exchange-rate conversion in the reports.</li>
</ul>

<h2>Downloads</h2>
<ul>
<li><a href="report-2026.xlsx">report-2026.xlsx</a>: the Excel report (4 sheets)</li>
<li><a href="transactions-2026.csv">transactions-2026.csv</a> and <a href="summary-2026.csv">summary-2026.csv</a>: the same data as CSV</li>
<li><a href="schema.sql">schema.sql</a>: MySQL schema (10 tables), exported from the running database</li>
<li><a href="api.html">api.html</a> and <a href="openapi.json">openapi.json</a>: the API reference</li>
<li><a href="wholesale-oms-source.zip">wholesale-oms-source.zip</a>: source code, tests, README, saved walkthrough</li>
</ul>
<p class="small">Sample data is fictional. Built with Python 3.12, FastAPI, SQLAlchemy, MySQL 8.4 and openpyxl.</p>
""" + FOOT

# ---------------- API reference ----------------
rows = []
for path, ops in spec["paths"].items():
    for m, op in ops.items():
        if (path, m) in PUBLIC:
            role = "public"
        elif ADMIN_ONLY(path, m):
            role = "admin"
        else:
            role = "staff, admin"
        rows.append((op.get("tags", [""])[0], path, m.upper(), role, op.get("summary", "")))
rows.sort(key=lambda r: (r[0], r[1], r[2]))
trs = "".join(f"<tr><td>{e(t)}</td><td><b>{m}</b></td><td><code>{e(p)}</code></td><td>{e(r)}</td><td>{e(s)}</td></tr>" for t, p, m, r, s in rows)
api = HEAD.replace("{title}", "Wholesale OMS API reference").replace("{desc}", "Endpoint list generated from the OpenAPI file of the demo backend.") + f"""
<h1>API reference</h1>
<p class="lead">{len(rows)} endpoints, generated from the OpenAPI file of the running service ({e(spec['info']['title'])} {e(spec['info']['version'])}). Log in at <code>POST /auth/token</code>, then send <code>Authorization: Bearer &lt;token&gt;</code>.</p>
<div class="actions"><a class="btn alt" href="openapi.json">openapi.json</a><a class="btn alt" href="./">Back to the demo</a></div>
<div class="scroll"><table class="t"><thead><tr><th>Area</th><th>Method</th><th>Path</th><th>Who</th><th>What it does</th></tr></thead><tbody>{trs}</tbody></table></div>
<p class="small">Money is returned as exact decimal strings. List endpoints take <code>page</code> and <code>page_size</code>. Errors use plain messages: 401 not logged in, 403 wrong role, 404 not found, 409 not allowed in the current state, 422 invalid input.</p>
""" + FOOT

OUT.mkdir(parents=True, exist_ok=True)
(OUT / "index.html").write_text(index)
(OUT / "api.html").write_text(api)
print("built", OUT)
