# Wholesale Order & VAT Reporting API

A backend for a wholesale business: create and manage orders, record payments and refunds, calculate VAT per line,
and produce monthly and quarterly summaries that export to Excel or CSV for the accountant.

Python 3.12, FastAPI, SQLAlchemy 2, **MySQL 8.4**, JWT login, openpyxl. All money is `Decimal` (`DECIMAL(14,2)` in MySQL), never float.

> The default VAT preset (China, VAT Law in force 1 Jan 2026) is **data, not code**. The rates are marked "per 2026 VAT Law
> summaries; confirm with your accountant". Please have an accountant confirm the rates and the rounding approach before real filing.

## What it does

- **Orders**: customers, products, orders with lines. Workflow `draft -> confirmed -> shipped -> completed`; cancel only from draft or confirmed.
  Lines are editable only in draft. Totals are always recomputed on the server. Illegal moves return `409` with a clear message.
- **Prices**: per order, tax-inclusive (common for Chinese wholesale quotes) or tax-exclusive. Line discounts and an order-level discount
  (spread over the lines in proportion to line value; the last line takes the rounding remainder). Discounts reduce the taxable base.
- **Payments and refunds**: partial or full, refund linked to a payment, cannot exceed it. Payment status is derived:
  `unpaid / partially_paid / paid / overpaid / partially_refunded / refunded`. Fields for the invoice (fapiao) number on orders and a credit-note reference on refunds.
- **Reports**: monthly and quarterly summaries (orders, discounts, net sales, output VAT, refunds net + VAT, payments received, outstanding receivables),
  VAT by rate, per-customer breakdown, and a transaction ledger (every order line, payment and refund). Export as CSV or an Excel workbook
  (Summary, By rate, By customer, Transactions).
- **Auth and roles**: OAuth2 password flow with JWT. `admin` manages users, tax rates, settings and reads the audit log. `staff` manages customers, orders, payments, refunds. Both read reports.
- **Audit log**: who, when, old and new values for every change to orders, payments, refunds, tax rates, users and settings.

## Setup

### With Docker Compose (MySQL + app)

```bash
cp .env.example .env            # then edit: set real passwords and JWT_SECRET (openssl rand -hex 32)
docker compose up -d --build    # MySQL 8.4 on host port 3307, API on http://localhost:8000
docker compose exec app python -m app.cli create-admin admin     # prompts for the password
```
API docs: http://localhost:8000/docs

### Local (MySQL in Docker, app in a virtualenv)

```bash
cp .env.example .env            # edit values; DB_HOST=127.0.0.1 DB_PORT=3307
docker run -d --name oms-mysql -p 3307:3306 \
  -e MYSQL_ROOT_PASSWORD -e MYSQL_DATABASE -e MYSQL_USER -e MYSQL_PASSWORD -e TZ=UTC \
  mysql:8.4 --character-set-server=utf8mb4 --collation-server=utf8mb4_0900_ai_ci   # with the .env values exported
python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python -m app.cli init-db               # creates tables, seeds the tax preset and settings (safe to repeat)
.venv/bin/python -m app.cli create-admin admin    # first admin; password prompted (or env OMS_ADMIN_PASSWORD). No default password exists.
.venv/bin/uvicorn app.main:app --port 8000
```
Start / stop the database later: `docker start oms-mysql` / `docker stop oms-mysql`.
The plain-SQL schema is in `schema.sql` (a `mysqldump --no-data` of the real database).

### Sample data and walkthrough

```bash
OMS_STAFF_PASSWORD=... .venv/bin/python -m scripts.seed_demo        # fictional customers and ~30 orders, Jul-Nov 2026
OMS_USER=sample.staff OMS_PASSWORD=... .venv/bin/python -m scripts.walkthrough   # drives the live API, saves demo-run/*.json
```

## Tests

```bash
.venv/bin/python -m pytest -q
```
Tests run against the **real MySQL** container (database `oms_test`, created on first run if `MYSQL_ROOT_PASSWORD` is in `.env`; otherwise create it and grant the app user).
Result of the last run is in `test-results.txt`.

## Tax rules (default preset: China VAT, 2026)

| Taxpayer type | Category | Rate | Valid |
|---|---|---|---|
| general | standard goods | 13% | from 2026-01-01 |
| general | reduced goods (e.g. agricultural products, books) | 9% | from 2026-01-01 |
| general | services | 6% | from 2026-01-01 |
| general | export | 0% (zero-rated) | from 2026-01-01 |
| small_scale | standard / reduced / service | 3% levy rate | from 2026-01-01 |
| small_scale | standard / reduced / service | 1% preferential | 2026-01-01 to 2027-12-31 |
| small_scale | export | 0% | from 2026-01-01 |

Per 2026 VAT Law summaries; confirm with your accountant. The business taxpayer type is an admin setting (`PUT /settings`).

How a rate is chosen: by (jurisdiction, taxpayer type, product tax category, **order date**); among the rows whose validity window contains the date, the one with the latest `valid_from` wins
(that is how the 1% row overrides the 3% row until 2027-12-31, after which 3% applies again). Customers flagged `is_export` use the `export` category (0%).
The rate is **snapshotted on each order line** when the order is built; after confirmation it is never recomputed, so changing a rate row cannot rewrite a past order.

Rounding: `ROUND_HALF_UP` to 0.01 per line. Tax-inclusive: `net = round(gross / (1 + rate))`, `tax = gross - net`. Tax-exclusive: `tax = round(net * rate)`.

### Adding another country

It is rows, not code. Add rate rows with a new `jurisdiction` and your own taxpayer types and categories, then switch the settings:

```bash
curl -X POST /tax-rates -d '{"jurisdiction":"DE","taxpayer_type":"regular","tax_category":"standard","rate":"0.1900","valid_from":"2020-01-01"}'
curl -X POST /tax-rates -d '{"jurisdiction":"DE","taxpayer_type":"regular","tax_category":"export","rate":"0.0000","valid_from":"2020-01-01"}'
curl -X PUT  /settings  -d '{"jurisdiction":"DE","taxpayer_type":"regular","currency":"EUR"}'
```
(A test does exactly this.) Product tax categories are free text keys that must have rate rows (`standard`, `reduced`, `service` in the preset; `export` is used automatically for export customers).

## Reporting rules

- Sales are counted by **order date** for orders that are confirmed, shipped or completed (drafts and cancelled orders are not sales).
- A refund is a **credit in the period of the refund** (not the order's period). Its VAT part is `round(refund * order VAT / order total)`; refunds on a mixed-rate order are spread over the rates, so the by-rate report adds up.
- Payment and refund dates use the business time zone (setting `timezone`, default `Asia/Shanghai`); timestamps are stored in UTC.
- Outstanding receivables = invoiced amount of the period's orders minus payments received up to the end of that period.
- Everything is derived from one ledger (`GET /reports/transactions`), so the summaries always equal the sum of the ledger (a test checks this).

## API overview

Interactive docs at `/docs`; the schema is saved as `openapi.json`. Auth: `POST /auth/token` (form: `username`, `password`), then `Authorization: Bearer <token>`.

| Area | Endpoints | Who |
|---|---|---|
| Auth | `POST /auth/token`, `GET /auth/me` | all |
| Users | `GET/POST /users`, `PATCH /users/{id}` | admin |
| Settings, rates | `GET /settings`, `GET /tax-rates`, `GET /tax-rates/lookup` | staff, admin |
| | `PUT /settings`, `POST/PATCH /tax-rates` | admin |
| Customers, products | `GET/POST /customers`, `GET/PATCH /customers/{id}`, `GET/POST /products`, `PATCH /products/{id}` | staff, admin |
| Orders | `GET/POST /orders`, `GET/PATCH /orders/{id}`, `PUT/POST /orders/{id}/lines`, `DELETE /orders/{id}/lines/{line}`, `POST /orders/{id}/status` | staff, admin |
| Payments, refunds | `POST/GET /orders/{id}/payments`, `POST /payments/{id}/refunds`, `GET /orders/{id}/refunds`, `GET /payments`, `GET /refunds` | staff, admin |
| Reports | `GET /reports/summary`, `/by-rate`, `/by-customer`, `/transactions`, `/export.csv`, `/export.xlsx` | staff, admin |
| Audit | `GET /audit-log` | admin |

List endpoints take `page`, `page_size`; orders filter by `status`, `customer_id`, `date_from`, `date_to`, `q`. Money in responses is an exact decimal string (`"88.50"`).

## Project layout

```
app/        main.py routers.py services.py (workflow, payments, refunds, audit) tax.py (pure arithmetic) reports.py (ledger, exports) models.py schemas.py security.py cli.py
scripts/    seed_demo.py  walkthrough.py  gen_api_ref.py  build_site.py
tests/      real-MySQL test suite
schema.sql  openapi.json  demo-run/ (saved HTTP walkthrough)  samples/ (Excel and CSV from the seeded data)
```

## Known limits

- No Golden Tax / e-fapiao integration: invoice numbers and credit-note references are plain fields.
- Rates and rules are a starting preset from public summaries of the 2026 VAT Law, not tax advice. Special cases (input VAT deduction, mixed-sales rules, withholding, local surcharges) are out of scope: this reports **output VAT** only.
- Single currency per order, no FX conversion in reports (report rows carry the currency).
- Orders cannot be edited after confirmation except notes and the fapiao number; corrections are done with refunds/credits.
- Refunds are money refunds only: no return-to-stock, and a refund does not change the order's own total.
- The compose file was written for a normal Docker host; it has not been run in the build environment (the local run used MySQL in Docker and the app in a virtualenv).
- Tables are created with SQLAlchemy `create_all` (schema.sql is provided); there are no Alembic migrations yet.
- No rate limiting or password-reset flow; JWTs are valid for 8 hours.
