"""Tests run against a REAL MySQL 8.4 (database `oms_test`), never SQLite."""
import os
import subprocess
from decimal import Decimal

os.environ["MYSQL_DATABASE"] = "oms_test"
os.environ["BCRYPT_ROUNDS"] = "4"  # fast hashing for tests only
os.environ.setdefault("JWT_SECRET", "test-only-secret-not-used-anywhere-else-0123456789")

import pytest
import pymysql
from fastapi.testclient import TestClient
from sqlalchemy import text

from app.config import get_settings
from app.db import Base, SessionLocal, engine
from app.main import app
from app.models import User
from app.rates_seed import seed_defaults
from app.security import hash_password

PW = "correct-horse-battery"
PW_HASH = hash_password(PW)


def _ensure_test_db():
    s = get_settings()
    root_pw = os.environ.get("MYSQL_ROOT_PASSWORD") or _env_file_value("MYSQL_ROOT_PASSWORD")
    if not root_pw:
        return  # assume the database already exists and is granted
    c = pymysql.connect(host=s.db_host, port=s.db_port, user="root", password=root_pw)
    with c.cursor() as cur:
        cur.execute("CREATE DATABASE IF NOT EXISTS oms_test CHARACTER SET utf8mb4")
        cur.execute(f"GRANT ALL ON oms_test.* TO '{s.mysql_user}'@'%'")
    c.close()


def _env_file_value(key):
    try:
        for line in open(".env"):
            if line.startswith(key + "="):
                return line.strip().split("=", 1)[1]
    except OSError:
        pass
    return None


@pytest.fixture(scope="session", autouse=True)
def schema():
    _ensure_test_db()
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    yield


@pytest.fixture(autouse=True)
def clean():
    with engine.begin() as c:
        c.execute(text("SET FOREIGN_KEY_CHECKS=0"))
        for t in reversed(Base.metadata.sorted_tables):
            c.execute(text(f"DELETE FROM `{t.name}`"))
        c.execute(text("SET FOREIGN_KEY_CHECKS=1"))
    with SessionLocal() as db:
        seed_defaults(db)
        db.add_all([User(username="admin", role="admin", password_hash=PW_HASH),
                    User(username="staff", role="staff", password_hash=PW_HASH)])
        db.commit()


@pytest.fixture
def client():
    return TestClient(app)


def _login(client, user):
    r = client.post("/auth/token", data={"username": user, "password": PW})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


@pytest.fixture
def admin(client):
    return _login(client, "admin")


@pytest.fixture
def staff(client):
    return _login(client, "staff")


@pytest.fixture
def cust(client, staff):
    return client.post("/customers", json={"name": "Sample Trading Co. A"}, headers=staff).json()


@pytest.fixture
def export_cust(client, staff):
    return client.post("/customers", json={"name": "Sample Export Ltd", "is_export": True}, headers=staff).json()


def D(x):
    return Decimal(str(x))


def new_order(client, h, customer, lines, **kw):
    body = {"customer_id": customer["id"], "order_date": "2026-09-10", **kw, "lines": lines}
    r = client.post("/orders", json=body, headers=h)
    assert r.status_code == 201, r.text
    return r.json()


def line(price="100.00", qty="1", cat="standard", disc="0.00", desc="Item"):
    return {"description": desc, "quantity": qty, "unit_price": price, "tax_category": cat, "line_discount": disc}


def go(client, h, oid, status):
    return client.post(f"/orders/{oid}/status", json={"status": status}, headers=h)
