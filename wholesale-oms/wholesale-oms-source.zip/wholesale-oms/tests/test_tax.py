from decimal import Decimal

from app.tax import allocate, compute_order, LineInput, split_amount
from conftest import D, go, line, new_order


# ---- pure arithmetic ----
def test_inclusive_rounding_net_plus_tax_equals_gross():
    assert split_amount(D("100.00"), D("0.13"), True) == (D("88.50"), D("11.50"), D("100.00"))
    net, tax, gross = split_amount(D("33.33"), D("0.13"), True)  # 29.4956 -> 29.50
    assert (net, tax, gross) == (D("29.50"), D("3.83"), D("33.33"))


def test_exclusive_rounding_half_up():
    assert split_amount(D("100.05"), D("0.13"), False) == (D("100.05"), D("13.01"), D("113.06"))  # 13.0065
    assert split_amount(D("0.50"), D("0.09"), False)[1] == D("0.05")  # 0.045 rounds half up


def test_allocation_sums_exactly_and_last_takes_remainder():
    shares = allocate(D("10.00"), [D("100"), D("200"), D("300")])
    assert shares == [D("1.67"), D("3.33"), D("5.00")]
    assert sum(shares) == D("10.00")
    assert allocate(D("0.01"), [D("1"), D("1"), D("1")]) == [D("0.00"), D("0.00"), D("0.01")]


def test_no_float_anywhere():
    res = compute_order([LineInput(D("3"), D("19.99"), D("0"), D("0.13"))], False, D("0"))
    assert all(isinstance(x, Decimal) for x in (res[0].net, res[0].tax, res[0].gross))


# ---- through the API ----
def test_inclusive_order_totals(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00", "1")], price_mode="inclusive")
    assert (o["gross_total"], o["net_total"], o["tax_total"]) == ("100.00", "88.50", "11.50")
    assert o["lines"][0]["tax_rate"] == "0.1300"


def test_exclusive_order_totals(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.05", "1")], price_mode="exclusive")
    assert (o["net_total"], o["tax_total"], o["gross_total"]) == ("100.05", "13.01", "113.06")


def test_mixed_rates_in_one_order(client, staff, cust):
    o = new_order(client, staff, cust, [line("113.00", cat="standard"), line("109.00", cat="reduced"),
                                        line("106.00", cat="service")])
    assert [ln["tax_rate"] for ln in o["lines"]] == ["0.1300", "0.0900", "0.0600"]
    assert [ln["net_amount"] for ln in o["lines"]] == ["100.00", "100.00", "100.00"]
    assert (o["net_total"], o["tax_total"], o["gross_total"]) == ("300.00", "28.00", "328.00")


def test_order_discount_allocated_proportionally_and_sums_exactly(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00"), line("200.00"), line("300.00")], discount="10.00")
    assert [ln["order_discount_alloc"] for ln in o["lines"]] == ["1.67", "3.33", "5.00"]
    assert sum(D(ln["order_discount_alloc"]) for ln in o["lines"]) == D("10.00")
    assert o["gross_total"] == "590.00"
    assert D(o["net_total"]) + D(o["tax_total"]) == D(o["gross_total"])
    assert sum(D(ln["gross_amount"]) for ln in o["lines"]) == D(o["gross_total"])
    assert o["discount_total"] == "10.00"


def test_discounts_reduce_taxable_base(client, staff, cust):
    o = new_order(client, staff, cust, [line("1000.00", disc="100.00")], price_mode="exclusive", discount="0.00")
    assert (o["net_total"], o["tax_total"]) == ("900.00", "117.00")
    o2 = new_order(client, staff, cust, [line("1000.00", disc="100.00")], price_mode="exclusive", discount="90.00")
    assert (o2["net_total"], o2["tax_total"], o2["discount_total"]) == ("810.00", "105.30", "190.00")


def test_discount_larger_than_value_rejected(client, staff, cust):
    r = client.post("/orders", json={"customer_id": cust["id"], "order_date": "2026-09-10",
                                     "lines": [line("10.00")], "discount": "20.00"}, headers=staff)
    assert r.status_code == 422


def test_quantity_precision_validated(client, staff, cust):
    r = client.post("/orders", json={"customer_id": cust["id"], "lines": [line("10.00", qty="1.2345")]}, headers=staff)
    assert r.status_code == 422


def test_zero_rated_export(client, staff, export_cust):
    o = new_order(client, staff, export_cust, [line("1000.00", cat="standard"), line("500.00", cat="service")])
    assert [ln["tax_rate"] for ln in o["lines"]] == ["0.0000", "0.0000"]
    assert (o["net_total"], o["tax_total"], o["gross_total"]) == ("1500.00", "0.00", "1500.00")


def test_rate_effective_dates_small_scale(client, admin):
    def rate(on, typ="small_scale"):
        r = client.get("/tax-rates/lookup", params={"tax_category": "standard", "on": on, "taxpayer_type": typ}, headers=admin)
        return r.status_code, (r.json()["rate"] if r.status_code == 200 else None)
    assert rate("2026-01-01") == (200, "0.0100")
    assert rate("2027-12-31") == (200, "0.0100")
    assert rate("2028-01-01") == (200, "0.0300")
    assert rate("2026-06-30", "general") == (200, "0.1300")
    assert rate("2025-12-31", "general")[0] == 422  # before the preset starts


def test_small_scale_orders_use_dated_rate(client, admin, staff, cust):
    assert client.put("/settings", json={"taxpayer_type": "small_scale"}, headers=admin).status_code == 200
    a = new_order(client, staff, cust, [line("1010.00")], order_date="2027-12-31")
    b = new_order(client, staff, cust, [line("1030.00")], order_date="2028-01-01")
    assert (a["lines"][0]["tax_rate"], a["net_total"], a["tax_total"]) == ("0.0100", "1000.00", "10.00")
    assert (b["lines"][0]["tax_rate"], b["net_total"], b["tax_total"]) == ("0.0300", "1000.00", "30.00")


def test_snapshot_rate_change_does_not_rewrite_old_order(client, admin, staff, cust):
    o = new_order(client, staff, cust, [line("113.00")])
    assert go(client, staff, o["id"], "confirmed").status_code == 200
    rates = client.get("/tax-rates", params={"taxpayer_type": "general"}, headers=admin).json()
    std = next(r for r in rates if r["tax_category"] == "standard")
    body = {k: std[k] for k in ("jurisdiction", "taxpayer_type", "tax_category", "valid_from", "valid_to", "label", "note")}
    assert client.patch(f"/tax-rates/{std['id']}", json={**body, "rate": "0.1700"}, headers=admin).status_code == 200
    old = client.get(f"/orders/{o['id']}", headers=staff).json()
    assert (old["lines"][0]["tax_rate"], old["tax_total"], old["net_total"]) == ("0.1300", "13.00", "100.00")
    # even an unrelated edit of a confirmed order keeps the snapshot
    client.patch(f"/orders/{o['id']}", json={"fapiao_no": "FP-1"}, headers=staff)
    assert client.get(f"/orders/{o['id']}", headers=staff).json()["tax_total"] == "13.00"
    fresh = new_order(client, staff, cust, [line("117.00")])
    assert (fresh["lines"][0]["tax_rate"], fresh["tax_total"]) == ("0.1700", "17.00")


def test_another_country_is_new_rows_not_new_code(client, admin, staff, cust):
    """Add a made-up Germany-style preset purely as data, switch the setting, and orders use it."""
    for cat, rate in (("standard", "0.1900"), ("reduced", "0.0700"), ("export", "0.0000")):
        r = client.post("/tax-rates", json={"jurisdiction": "DE", "taxpayer_type": "regular", "tax_category": cat,
                                            "rate": rate, "valid_from": "2020-01-01", "note": "test data"}, headers=admin)
        assert r.status_code == 201
    bad = client.put("/settings", json={"jurisdiction": "DE", "taxpayer_type": "general"}, headers=admin)
    assert bad.status_code == 422  # no such combination
    assert client.put("/settings", json={"jurisdiction": "DE", "taxpayer_type": "regular", "currency": "EUR"}, headers=admin).status_code == 200
    o = new_order(client, staff, cust, [line("119.00"), line("107.00", cat="reduced")])
    assert [ln["tax_rate"] for ln in o["lines"]] == ["0.1900", "0.0700"]
    assert (o["net_total"], o["tax_total"], o["gross_total"], o["currency"]) == ("200.00", "26.00", "226.00", "EUR")
