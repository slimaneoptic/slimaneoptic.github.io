from conftest import go, line, new_order



def test_full_happy_path(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00")])
    assert o["status"] == "draft" and o["number"].startswith("SO-2026-")
    for s in ("confirmed", "shipped", "completed"):
        r = go(client, staff, o["id"], s)
        assert r.status_code == 200 and r.json()["status"] == s


def test_illegal_transitions_return_409_with_message(client, staff, cust):
    o = new_order(client, staff, cust, [line()])
    r = go(client, staff, o["id"], "shipped")
    assert r.status_code == 409 and "Cannot move" in r.json()["detail"] and "confirmed, cancelled" in r.json()["detail"]
    go(client, staff, o["id"], "confirmed"); go(client, staff, o["id"], "shipped")
    assert go(client, staff, o["id"], "cancelled").status_code == 409  # cancel only from draft/confirmed
    assert go(client, staff, o["id"], "draft").status_code == 409
    go(client, staff, o["id"], "completed")
    assert go(client, staff, o["id"], "cancelled").status_code == 409
    assert go(client, staff, o["id"], "confirmed").status_code == 409


def test_cancel_from_draft_and_confirmed_then_final(client, staff, cust):
    a = new_order(client, staff, cust, [line()])
    assert go(client, staff, a["id"], "cancelled").status_code == 200
    b = new_order(client, staff, cust, [line()])
    go(client, staff, b["id"], "confirmed")
    assert go(client, staff, b["id"], "cancelled").status_code == 200
    assert go(client, staff, b["id"], "confirmed").status_code == 409
    assert client.patch(f"/orders/{b['id']}", json={"notes": "x"}, headers=staff).status_code == 409


def test_lines_editable_only_in_draft(client, staff, cust):
    o = new_order(client, staff, cust, [line("113.00")])
    r = client.post(f"/orders/{o['id']}/lines", json=line("50.00"), headers=staff)
    assert r.status_code == 201 and len(r.json()["lines"]) == 2 and r.json()["gross_total"] == "163.00"
    r = client.delete(f"/orders/{o['id']}/lines/{r.json()['lines'][1]['id']}", headers=staff)
    assert r.json()["gross_total"] == "113.00"
    r = client.put(f"/orders/{o['id']}/lines", json=[line("20.00"), line("30.00")], headers=staff)
    assert r.json()["gross_total"] == "50.00"
    go(client, staff, o["id"], "confirmed")
    for resp in (client.post(f"/orders/{o['id']}/lines", json=line(), headers=staff),
                 client.put(f"/orders/{o['id']}/lines", json=[line()], headers=staff),
                 client.patch(f"/orders/{o['id']}", json={"discount": "1.00"}, headers=staff),
                 client.delete(f"/orders/{o['id']}/lines/{o['lines'][0]['id']}", headers=staff)):
        assert resp.status_code == 409 and "draft" in resp.json()["detail"]
    # non-pricing fields (fapiao number) stay editable
    r = client.patch(f"/orders/{o['id']}", json={"fapiao_no": "FP-2026-0001"}, headers=staff)
    assert r.status_code == 200 and r.json()["fapiao_no"] == "FP-2026-0001"


def test_cannot_confirm_empty_order(client, staff, cust):
    o = new_order(client, staff, cust, [])
    assert go(client, staff, o["id"], "confirmed").status_code == 409


def test_payment_statuses(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00")])
    pay = lambda amt: client.post(f"/orders/{o['id']}/payments", json={"amount": amt}, headers=staff)
    assert pay("10.00").status_code == 409  # draft
    go(client, staff, o["id"], "confirmed")
    st = lambda: client.get(f"/orders/{o['id']}", headers=staff).json()
    assert st()["payment_status"] == "unpaid" and st()["balance_due"] == "100.00"
    pay("40.00")
    assert st()["payment_status"] == "partially_paid" and st()["balance_due"] == "60.00"
    pay("60.00")
    assert st()["payment_status"] == "paid" and st()["balance_due"] == "0.00"
    pay("5.00")
    assert st()["payment_status"] == "overpaid"
    assert client.post(f"/orders/{o['id']}/payments", json={"amount": "0"}, headers=staff).status_code == 422


def test_refunds_status_cap_and_vat_share(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00")], price_mode="exclusive")  # net 100, VAT 13, gross 113
    go(client, staff, o["id"], "confirmed")
    p = client.post(f"/orders/{o['id']}/payments", json={"amount": "113.00", "reference": "TT-1"}, headers=staff).json()
    ref = lambda amt, **kw: client.post(f"/payments/{p['id']}/refunds", json={"amount": amt, **kw}, headers=staff)
    r1 = ref("56.50", reason="damaged goods", credit_note_no="CN-001")
    assert r1.status_code == 201
    b = r1.json()
    assert (b["amount"], b["vat_amount"], b["net_amount"], b["credit_note_no"]) == ("56.50", "6.50", "50.00", "CN-001")
    assert client.get(f"/orders/{o['id']}", headers=staff).json()["payment_status"] == "partially_refunded"
    over = ref("56.51")
    assert over.status_code == 409 and "exceeds" in over.json()["detail"]
    r2 = ref("56.50")
    assert r2.json()["vat_amount"] == "6.50"
    assert client.get(f"/orders/{o['id']}", headers=staff).json()["payment_status"] == "refunded"
    assert ref("0.01").status_code == 409  # nothing left on that payment
    assert client.post("/payments/99999/refunds", json={"amount": "1.00"}, headers=staff).status_code == 404


def test_cannot_cancel_with_unrefunded_payment(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00")])
    go(client, staff, o["id"], "confirmed")
    p = client.post(f"/orders/{o['id']}/payments", json={"amount": "50.00"}, headers=staff).json()
    assert go(client, staff, o["id"], "cancelled").status_code == 409
    client.post(f"/payments/{p['id']}/refunds", json={"amount": "50.00"}, headers=staff)
    assert go(client, staff, o["id"], "cancelled").status_code == 200


def test_list_filters_and_pagination(client, staff, cust, export_cust):
    ids = []
    for i, d in enumerate(["2026-07-05", "2026-08-05", "2026-09-05", "2026-10-05", "2026-11-05"]):
        c = export_cust if i == 4 else cust
        ids.append(new_order(client, staff, c, [line()], order_date=d)["id"])
    go(client, staff, ids[0], "confirmed")
    r = client.get("/orders", params={"page_size": 2, "page": 1}, headers=staff).json()
    assert r["total"] == 5 and len(r["items"]) == 2 and r["items"][0]["id"] == ids[4]  # newest first
    assert len(client.get("/orders", params={"page_size": 2, "page": 3}, headers=staff).json()["items"]) == 1
    assert client.get("/orders", params={"status": "confirmed"}, headers=staff).json()["total"] == 1
    assert client.get("/orders", params={"customer_id": export_cust["id"]}, headers=staff).json()["total"] == 1
    r = client.get("/orders", params={"date_from": "2026-08-01", "date_to": "2026-10-31"}, headers=staff).json()
    assert r["total"] == 3
    assert client.get("/customers", params={"is_export": True}, headers=staff).json()["total"] == 1
