from conftest import PW, go, line, new_order


def test_login_failures(client):
    assert client.post("/auth/token", data={"username": "admin", "password": "wrong-password"}).status_code == 401
    assert client.post("/auth/token", data={"username": "nobody", "password": PW}).status_code == 401
    assert client.get("/orders").status_code == 401
    assert client.get("/orders", headers={"Authorization": "Bearer garbage"}).status_code == 401
    assert client.get("/reports/summary", params={"year": 2026}).status_code == 401


def test_me_and_inactive_user(client, admin):
    assert client.get("/auth/me", headers=admin).json()["role"] == "admin"
    r = client.post("/users", json={"username": "temp.user", "password": "a-long-password-1", "role": "staff"}, headers=admin)
    assert r.status_code == 201
    tok = client.post("/auth/token", data={"username": "temp.user", "password": "a-long-password-1"}).json()["access_token"]
    h = {"Authorization": f"Bearer {tok}"}
    assert client.get("/auth/me", headers=h).status_code == 200
    client.patch(f"/users/{r.json()['id']}", json={"is_active": False}, headers=admin)
    assert client.get("/auth/me", headers=h).status_code == 401  # existing token stops working
    assert client.post("/auth/token", data={"username": "temp.user", "password": "a-long-password-1"}).status_code == 401


def test_staff_cannot_do_admin_things(client, staff, admin):
    assert client.get("/users", headers=staff).status_code == 403
    assert client.post("/users", json={"username": "x.user", "password": "a-long-password-1"}, headers=staff).status_code == 403
    assert client.put("/settings", json={"taxpayer_type": "small_scale"}, headers=staff).status_code == 403
    rate = {"taxpayer_type": "general", "tax_category": "standard", "rate": "0.2", "valid_from": "2030-01-01"}
    assert client.post("/tax-rates", json=rate, headers=staff).status_code == 403
    assert client.get("/audit-log", headers=staff).status_code == 403
    # but staff can read settings, rates and reports
    assert client.get("/settings", headers=staff).status_code == 200
    assert client.get("/tax-rates", headers=staff).status_code == 200
    assert client.get("/reports/summary", params={"year": 2026}, headers=staff).status_code == 200
    assert client.get("/reports/export.xlsx", params={"year": 2026}, headers=staff).status_code == 200
    # admin can do all of it
    assert client.post("/tax-rates", json=rate, headers=admin).status_code == 201
    assert client.put("/settings", json={"business_name": "Test Co"}, headers=admin).json()["business_name"] == "Test Co"
    assert client.get("/audit-log", headers=admin).status_code == 200


def test_staff_runs_orders_payments_refunds(client, staff, cust):
    o = new_order(client, staff, cust, [line()])
    assert go(client, staff, o["id"], "confirmed").status_code == 200
    p = client.post(f"/orders/{o['id']}/payments", json={"amount": "10.00"}, headers=staff)
    assert p.status_code == 201
    assert client.post(f"/payments/{p.json()['id']}/refunds", json={"amount": "5.00"}, headers=staff).status_code == 201


def test_admin_cannot_lock_self_out_and_duplicate_user(client, admin):
    me = client.get("/auth/me", headers=admin).json()
    assert client.patch(f"/users/{me['id']}", json={"is_active": False}, headers=admin).status_code == 409
    assert client.post("/users", json={"username": "staff", "password": "a-long-password-1"}, headers=admin).status_code == 409
    assert client.post("/users", json={"username": "short.pw", "password": "short"}, headers=admin).status_code == 422


def test_audit_trail_records_who_what_old_new(client, admin, staff, cust):
    o = new_order(client, staff, cust, [line("113.00")])
    go(client, staff, o["id"], "confirmed")
    p = client.post(f"/orders/{o['id']}/payments", json={"amount": "50.00"}, headers=staff).json()
    client.post(f"/payments/{p['id']}/refunds", json={"amount": "10.00"}, headers=staff)
    rate = client.get("/tax-rates", headers=admin).json()[0]
    body = {k: rate[k] for k in ("taxpayer_type", "tax_category", "valid_from", "valid_to", "label", "note")}
    client.patch(f"/tax-rates/{rate['id']}", json={**body, "rate": "0.2500"}, headers=admin)
    log = client.get("/audit-log", params={"page_size": 100}, headers=admin).json()["items"]
    ents = {(e["entity"], e["action"]) for e in log}
    assert {("order", "create"), ("order", "status_confirmed"), ("payment", "create"), ("refund", "create"),
            ("tax_rate", "update")} <= ents
    conf = next(e for e in log if e["action"] == "status_confirmed")
    assert conf["username"] == "staff" and conf["old_value"]["status"] == "draft" and conf["new_value"]["status"] == "confirmed"
    upd = next(e for e in log if e["entity"] == "tax_rate")
    assert upd["username"] == "admin" and upd["new_value"]["rate"] == "0.2500" and upd["old_value"]["rate"] != "0.2500"
    only = client.get("/audit-log", params={"entity": "order", "entity_id": o["id"]}, headers=admin).json()
    assert only["total"] == 2


def test_docs_and_openapi_available(client):
    assert client.get("/docs").status_code == 200
    spec = client.get("/openapi.json").json()
    assert "/orders" in spec["paths"] and "/auth/token" in spec["paths"]
    assert client.get("/health").json() == {"status": "ok"}
