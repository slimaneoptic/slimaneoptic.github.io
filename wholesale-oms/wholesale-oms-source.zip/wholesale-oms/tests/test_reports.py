import csv
import io
from decimal import Decimal

from openpyxl import load_workbook

from conftest import D, go, line, new_order


def pay(client, h, oid, amount, at=None):
    body = {"amount": amount, **({"paid_at": at} if at else {})}
    r = client.post(f"/orders/{oid}/payments", json=body, headers=h)
    assert r.status_code == 201, r.text
    return r.json()


def scenario(client, staff, cust, export_cust):
    a = new_order(client, staff, cust, [line("113.00")], order_date="2026-09-10")            # net 100 vat 13
    go(client, staff, a["id"], "confirmed")
    p = pay(client, staff, a["id"], "100.00", "2026-09-15T10:00:00+08:00")
    client.post(f"/payments/{p['id']}/refunds", json={"amount": "56.50", "reason": "returned goods", "credit_note_no": "CN-1",
                                                      "refunded_at": "2026-10-05T10:00:00+08:00"}, headers=staff)
    b = new_order(client, staff, cust, [line("200.00", cat="reduced")], order_date="2026-10-20",
                  price_mode="exclusive", discount="20.00")                                   # net 180 vat 16.20
    go(client, staff, b["id"], "confirmed")
    c = new_order(client, staff, export_cust, [line("1000.00")], order_date="2026-11-02")      # export
    go(client, staff, c["id"], "confirmed")
    pay(client, staff, c["id"], "1000.00", "2026-11-10T09:00:00+08:00")
    new_order(client, staff, cust, [line("999.00")], order_date="2026-10-02")                  # draft: not a sale
    x = new_order(client, staff, cust, [line("777.00")], order_date="2026-10-03")
    go(client, staff, x["id"], "cancelled")                                                   # cancelled: not a sale
    return a, b, c


def test_monthly_and_quarterly_numbers(client, staff, cust, export_cust):
    scenario(client, staff, cust, export_cust)
    rows = {r["period"]: r for r in client.get("/reports/summary", params={"year": 2026}, headers=staff).json()}
    sep, octo, nov = rows["2026-09"], rows["2026-10"], rows["2026-11"]
    assert (sep["orders"], sep["net_sales"], sep["output_vat"], sep["payments_received"]) == (1, "100.00", "13.00", "100.00")
    assert sep["outstanding_receivables"] == "13.00"
    assert (octo["orders"], octo["net_sales"], octo["output_vat"], octo["total_invoiced"]) == (1, "180.00", "16.20", "196.20")
    # the refund is a credit in the month it happened (October), not in the order's month
    assert (octo["refunds_gross"], octo["refunds_vat"], octo["refunds_net"]) == ("56.50", "6.50", "50.00")
    assert octo["net_sales_after_refunds"] == "130.00" and octo["vat_after_refunds"] == "9.70"
    assert octo["discounts"] == "20.00" and octo["gross_before_discount"] == "200.00"
    assert octo["outstanding_receivables"] == "196.20"
    assert (nov["net_sales"], nov["output_vat"], nov["payments_received"], nov["outstanding_receivables"]) == \
        ("1000.00", "0.00", "1000.00", "0.00")
    q = {r["period"]: r for r in client.get("/reports/summary", params={"year": 2026, "period": "quarter"}, headers=staff).json()}
    assert set(q) == {f"2026-Q{i}" for i in (1, 2, 3, 4)}
    assert (q["2026-Q3"]["orders"], q["2026-Q3"]["net_sales"]) == (1, "100.00")
    assert (q["2026-Q4"]["orders"], q["2026-Q4"]["net_sales"], q["2026-Q4"]["output_vat"]) == (2, "1180.00", "16.20")
    y = rows["2026"]
    assert (y["net_sales"], y["output_vat"], y["refunds_vat"], y["vat_after_refunds"]) == ("1280.00", "29.20", "6.50", "22.70")


def test_report_totals_equal_ledger_and_orders(client, staff, cust, export_cust):
    scenario(client, staff, cust, export_cust)
    led = client.get("/reports/transactions", params={"date_from": "2026-01-01", "date_to": "2026-12-31"}, headers=staff).json()
    items = led["items"]
    assert {i["type"] for i in items} == {"order_line", "payment", "refund"}
    S = lambda t, k: sum((D(i[k]) for i in items if i["type"] == t), Decimal("0"))
    y = next(r for r in client.get("/reports/summary", params={"year": 2026, "period": "year"}, headers=staff).json())
    assert D(y["net_sales"]) == S("order_line", "net") and D(y["output_vat"]) == S("order_line", "vat")
    assert D(y["total_invoiced"]) == S("order_line", "gross")
    assert D(y["payments_received"]) == S("payment", "gross")
    assert D(y["refunds_vat"]) == -S("refund", "vat") and D(y["refunds_gross"]) == -S("refund", "gross")
    # ... and equal the order headers, computed independently of the ledger
    orders = client.get("/orders", params={"page_size": 100}, headers=staff).json()["items"]
    sold = [o for o in orders if o["status"] in ("confirmed", "shipped", "completed")]
    assert D(y["net_sales"]) == sum(D(o["net_total"]) for o in sold)
    assert D(y["output_vat"]) == sum(D(o["tax_total"]) for o in sold)
    assert y["orders"] == len(sold)
    # months add up to the year, quarters add up to the year, by-rate adds up to the summary
    allrows = client.get("/reports/summary", params={"year": 2026}, headers=staff).json()
    for k in ("net_sales", "output_vat", "refunds_vat", "payments_received", "total_invoiced"):
        assert sum(D(r[k]) for r in allrows if r["period_type"] == "month") == D(y[k])
        assert sum(D(r[k]) for r in allrows if r["period_type"] == "quarter") == D(y[k])
    br = client.get("/reports/by-rate", params={"year": 2026}, headers=staff).json()
    yr = [r for r in br if r["period_type"] == "year"]
    assert sum(D(r["net_sales"]) for r in yr) == D(y["net_sales"])
    assert sum(D(r["output_vat"]) for r in yr) == D(y["output_vat"])
    assert sum(D(r["refunds_vat"]) for r in yr) == D(y["refunds_vat"])
    assert {r["rate"] for r in yr} == {"0.1300", "0.0900", "0.0000"}


def test_by_customer(client, staff, cust, export_cust):
    scenario(client, staff, cust, export_cust)
    rows = client.get("/reports/by-customer", params={"date_from": "2026-01-01", "date_to": "2026-12-31"}, headers=staff).json()
    a = next(r for r in rows if r["customer"] == "Sample Trading Co. A")
    assert (a["orders"], a["net_sales"], a["output_vat"], a["refunds_gross"], a["payments_received"]) == \
        (2, "280.00", "29.20", "56.50", "100.00")
    assert a["outstanding_receivables"] == "209.20"  # 13.00 on the first order + 196.20 on the second


def test_refund_mixed_rates_splits_add_up(client, staff, cust):
    o = new_order(client, staff, cust, [line("113.00", cat="standard"), line("109.00", cat="reduced")], order_date="2026-09-10")
    go(client, staff, o["id"], "confirmed")
    p = pay(client, staff, o["id"], "222.00", "2026-09-12T10:00:00+08:00")
    r = client.post(f"/payments/{p['id']}/refunds", json={"amount": "55.55", "refunded_at": "2026-09-20T10:00:00+08:00"}, headers=staff).json()
    led = client.get("/reports/transactions", params={"date_from": "2026-09-01", "date_to": "2026-09-30", "type": "refund"}, headers=staff).json()["items"]
    assert len(led) == 2
    assert sum(D(i["gross"]) for i in led) == -D(r["amount"]) and sum(D(i["vat"]) for i in led) == -D(r["vat_amount"])
    assert sum(D(i["net"]) for i in led) == -D(r["net_amount"])


def test_payment_date_uses_business_timezone(client, staff, cust):
    o = new_order(client, staff, cust, [line("100.00")], order_date="2026-09-10")
    go(client, staff, o["id"], "confirmed")
    pay(client, staff, o["id"], "10.00", "2026-09-30T23:30:00+00:00")  # = 2026-10-01 07:30 in Asia/Shanghai
    rows = {r["period"]: r for r in client.get("/reports/summary", params={"year": 2026, "period": "month"}, headers=staff).json()}
    assert rows["2026-09"]["payments_received"] == "0.00" and rows["2026-10"]["payments_received"] == "10.00"


def test_csv_export(client, staff, cust, export_cust):
    scenario(client, staff, cust, export_cust)
    r = client.get("/reports/export.csv", params={"year": 2026, "kind": "transactions"}, headers=staff)
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    rows = list(csv.reader(io.StringIO(r.content.decode("utf-8-sig"))))
    assert rows[0][:4] == ["Date", "Type", "Order no.", "Customer"]
    types = [row[1] for row in rows[1:]]
    assert types.count("order_line") == 3 and types.count("payment") == 2 and types.count("refund") == 1
    vat_idx = rows[0].index("VAT")
    assert sum(Decimal(row[vat_idx]) for row in rows[1:] if row[1] == "order_line") == Decimal("29.20")
    assert client.get("/reports/export.csv", params={"year": 2026, "kind": "nope"}, headers=staff).status_code == 422


def test_xlsx_export_structure(client, staff, cust, export_cust):
    scenario(client, staff, cust, export_cust)
    r = client.get("/reports/export.xlsx", params={"year": 2026}, headers=staff)
    assert r.status_code == 200 and "spreadsheetml" in r.headers["content-type"]
    wb = load_workbook(io.BytesIO(r.content))
    assert wb.sheetnames == ["Summary", "By rate", "By customer", "Transactions"]
    for ws in wb:
        assert ws.freeze_panes == "A2" and ws["A1"].font.bold
        assert all(ws.column_dimensions[c].width > 5 for c in "ABC")
    t = wb["Transactions"]
    assert t["A2"].number_format == "yyyy-mm-dd" and t["J2"].number_format == "#,##0.00" and t["G2"].number_format == "0.00%"
    s = wb["Summary"]
    assert isinstance(s["F2"].value, (int, float, Decimal))  # numbers, not text
