"""Database schema. Money is DECIMAL(14,2), rates DECIMAL(6,4). No floats anywhere."""
from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import JSON, Boolean, Date, DateTime, ForeignKey, Index, Integer, Numeric, String, Text, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base

Money = Numeric(14, 2)
Rate = Numeric(6, 4)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True)
    full_name: Mapped[str] = mapped_column(String(120), default="")
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(16))  # admin | staff
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Customer(Base):
    __tablename__ = "customers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(160), index=True)
    tax_id: Mapped[str | None] = mapped_column(String(40), nullable=True)  # unified social credit code etc.
    address: Mapped[str] = mapped_column(String(300), default="")
    contact: Mapped[str] = mapped_column(String(160), default="")
    is_export: Mapped[bool] = mapped_column(Boolean, default=False)  # export customers are zero-rated
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(primary_key=True)
    sku: Mapped[str] = mapped_column(String(64), unique=True)
    name: Mapped[str] = mapped_column(String(160))
    unit: Mapped[str] = mapped_column(String(16), default="pcs")
    tax_category: Mapped[str] = mapped_column(String(16), default="standard")  # standard | reduced | service
    default_price: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)


class TaxRate(Base):
    """Effective-dated VAT rates. Another country = more rows, no code change."""
    __tablename__ = "tax_rates"
    id: Mapped[int] = mapped_column(primary_key=True)
    jurisdiction: Mapped[str] = mapped_column(String(8), default="CN")
    taxpayer_type: Mapped[str] = mapped_column(String(16))  # general | small_scale
    tax_category: Mapped[str] = mapped_column(String(16))  # standard | reduced | service | export
    rate: Mapped[Decimal] = mapped_column(Rate)
    valid_from: Mapped[date] = mapped_column(Date)
    valid_to: Mapped[date | None] = mapped_column(Date, nullable=True)  # inclusive; null = open ended
    label: Mapped[str] = mapped_column(String(80), default="")
    note: Mapped[str] = mapped_column(String(300), default="")
    __table_args__ = (Index("ix_rate_lookup", "jurisdiction", "taxpayer_type", "tax_category", "valid_from"),)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(String(300))


class Order(Base):
    __tablename__ = "orders"
    id: Mapped[int] = mapped_column(primary_key=True)
    number: Mapped[str] = mapped_column(String(32), unique=True)
    customer_id: Mapped[int] = mapped_column(ForeignKey("customers.id"), index=True)
    status: Mapped[str] = mapped_column(String(16), default="draft", index=True)
    price_mode: Mapped[str] = mapped_column(String(16), default="inclusive")  # inclusive | exclusive
    currency: Mapped[str] = mapped_column(String(3), default="CNY")
    order_date: Mapped[date] = mapped_column(Date, index=True)
    discount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))  # order-level discount
    notes: Mapped[str] = mapped_column(Text, default="")
    fapiao_no: Mapped[str | None] = mapped_column(String(40), nullable=True)  # invoice number (field only)
    # cached totals, recomputed server-side on every change
    list_total: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))      # qty * price as quoted
    discount_total: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))  # line + order discounts
    net_total: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    tax_total: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    gross_total: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))     # net + VAT = amount owed
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), onupdate=func.now())

    customer: Mapped[Customer] = relationship()
    lines: Mapped[list["OrderLine"]] = relationship(
        back_populates="order", cascade="all, delete-orphan", order_by="OrderLine.line_no")


class OrderLine(Base):
    __tablename__ = "order_lines"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id", ondelete="CASCADE"), index=True)
    line_no: Mapped[int] = mapped_column(Integer)
    product_id: Mapped[int | None] = mapped_column(ForeignKey("products.id"), nullable=True)
    description: Mapped[str] = mapped_column(String(200))
    quantity: Mapped[Decimal] = mapped_column(Numeric(14, 3))
    unit_price: Mapped[Decimal] = mapped_column(Money)
    line_discount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    # snapshot of the VAT rule used (a later rate change never rewrites this line)
    tax_category: Mapped[str] = mapped_column(String(16))
    tax_rate: Mapped[Decimal] = mapped_column(Rate)
    tax_rate_id: Mapped[int | None] = mapped_column(ForeignKey("tax_rates.id"), nullable=True)
    list_amount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    order_discount_alloc: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    net_amount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    tax_amount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    gross_amount: Mapped[Decimal] = mapped_column(Money, default=Decimal("0"))
    __table_args__ = (UniqueConstraint("order_id", "line_no"),)

    order: Mapped[Order] = relationship(back_populates="lines")


class Payment(Base):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Money)
    method: Mapped[str] = mapped_column(String(24), default="bank_transfer")
    reference: Mapped[str] = mapped_column(String(80), default="")
    paid_at: Mapped[datetime] = mapped_column(DateTime, index=True)  # stored as UTC
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class Refund(Base):
    __tablename__ = "refunds"
    id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("orders.id"), index=True)
    payment_id: Mapped[int] = mapped_column(ForeignKey("payments.id"), index=True)
    amount: Mapped[Decimal] = mapped_column(Money)       # gross, VAT included
    vat_amount: Mapped[Decimal] = mapped_column(Money)   # VAT part, proportional to the order's tax share
    net_amount: Mapped[Decimal] = mapped_column(Money)
    reason: Mapped[str] = mapped_column(String(200), default="")
    credit_note_no: Mapped[str | None] = mapped_column(String(40), nullable=True)  # red-letter fapiao / credit note ref
    refunded_at: Mapped[datetime] = mapped_column(DateTime, index=True)  # stored as UTC
    created_by: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)


class AuditLog(Base):
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[datetime] = mapped_column(DateTime, server_default=func.now(), index=True)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    username: Mapped[str] = mapped_column(String(64), default="system")
    entity: Mapped[str] = mapped_column(String(24), index=True)
    entity_id: Mapped[int] = mapped_column(Integer, index=True)
    action: Mapped[str] = mapped_column(String(32))
    old_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    new_value: Mapped[dict | None] = mapped_column(JSON, nullable=True)
