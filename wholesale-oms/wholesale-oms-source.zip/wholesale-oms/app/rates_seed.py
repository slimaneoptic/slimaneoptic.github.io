"""Default tax preset: China VAT, VAT Law in force 1 January 2026. This is DATA; edit via the API or add rows."""
from datetime import date

from sqlalchemy.orm import Session

from .models import Setting, TaxRate

NOTE = "per 2026 VAT Law summaries; confirm with your accountant"

DEFAULT_RATES = [
    # general taxpayer
    ("general", "standard", "0.1300", date(2026, 1, 1), None, "General taxpayer - goods 13%"),
    ("general", "reduced", "0.0900", date(2026, 1, 1), None, "General taxpayer - reduced-rate goods 9% (e.g. agricultural products, books)"),
    ("general", "service", "0.0600", date(2026, 1, 1), None, "General taxpayer - services 6%"),
    ("general", "export", "0.0000", date(2026, 1, 1), None, "Exports - zero-rated"),
    # small-scale taxpayer: 3% levy rate, preferential 1% for 2026-01-01 .. 2027-12-31
    *[("small_scale", c, "0.0300", date(2026, 1, 1), None, "Small-scale taxpayer - 3% levy rate")
      for c in ("standard", "reduced", "service")],
    *[("small_scale", c, "0.0100", date(2026, 1, 1), date(2027, 12, 31), "Small-scale taxpayer - preferential 1% (to 2027-12-31)")
      for c in ("standard", "reduced", "service")],
    ("small_scale", "export", "0.0000", date(2026, 1, 1), None, "Exports - zero-rated"),
]

DEFAULT_SETTINGS = {
    "jurisdiction": "CN",
    "taxpayer_type": "general",
    "business_name": "Sample Wholesale Co.",
    "currency": "CNY",
    "timezone": "Asia/Shanghai",
}


def seed_defaults(db: Session) -> None:
    """Idempotent: only inserts what is missing."""
    if db.query(TaxRate).count() == 0:
        for tp, cat, rate, vf, vt, label in DEFAULT_RATES:
            db.add(TaxRate(jurisdiction="CN", taxpayer_type=tp, tax_category=cat, rate=rate,
                           valid_from=vf, valid_to=vt, label=label, note=NOTE))
    for k, v in DEFAULT_SETTINGS.items():
        if db.get(Setting, k) is None:
            db.add(Setting(key=k, value=v))
    db.commit()
