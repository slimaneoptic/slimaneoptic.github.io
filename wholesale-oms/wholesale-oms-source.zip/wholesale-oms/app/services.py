"""Business logic: orders, payments, refunds, audit. Routers stay thin."""
from datetime import date, datetime, timezone
from decimal import Decimal
from zoneinfo import ZoneInfo

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .models import AuditLog, Customer, Order, OrderLine, Payment, Product, Refund, Setting, TaxRate, User
from .tax import LineInput, compute_order, q2

ZERO = Decimal("0.00")
TRANSITIONS = {
    "draft": {"confirmed", "cancelled"},
    "confirmed": {"shipped", "cancelled"},
    "shipped": {"completed"},
    "completed": set(),
    "cancelled": set(),
}


def conflict(msg: str) -> HTTPException:
    return HTTPException(409, msg)


# ---------- settings, time ----------
def get_setting(db: Session, key: str) -> str:
    s = db.get(Setting, key)
    if s is None:
        raise HTTPException(500, f"Setting '{key}' is missing; run `python -m app.cli init-db`")
    return s.value


def business_tz(db: Session) -> ZoneInfo:
    return ZoneInfo(get_setting(db, "timezone"))


def to_utc_naive(dt: datetime | None, tz: ZoneInfo) -> datetime:
    """Accept aware or naive datetimes (naive = business timezone); store naive UTC."""
    if dt is None:
        return datetime.now(timezone.utc).replace(tzinfo=None)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz)
    return dt.astimezone(timezone.utc).replace(tzinfo=None)


def local_date(dt_utc_naive: datetime, tz: ZoneInfo) -> date:
    return dt_utc_naive.replace(tzinfo=timezone.utc).astimezone(tz).date()


def local_range_to_utc(d_from: date, d_to: date, tz: ZoneInfo) -> tuple[datetime, datetime]:
    """Inclusive local dates -> [start, end) UTC naive datetimes."""
    from datetime import time, timedelta
    a = datetime.combine(d_from, time.min, tz).astimezone(timezone.utc).replace(tzinfo=None)
    b = datetime.combine(d_to + timedelta(days=1), time.min, tz).astimezone(timezone.utc).replace(tzinfo=None)
    return a, b


# ---------- audit ----------
def audit(db: Session, user: User | None, entity: str, entity_id: int, action: str, old=None, new=None) -> None:
    db.add(AuditLog(user_id=user.id if user else None, username=user.username if user else "system",
                    entity=entity, entity_id=entity_id, action=action, old_value=_j(old), new_value=_j(new)))


def _j(v):
    if v is None:
        return None
    return {k: (str(x) if isinstance(x, (Decimal, date, datetime)) else x) for k, x in v.items()}


def rate_snapshot(r: TaxRate) -> dict:
    return {"jurisdiction": r.jurisdiction, "taxpayer_type": r.taxpayer_type, "tax_category": r.tax_category,
            "rate": r.rate, "valid_from": r.valid_from, "valid_to": r.valid_to, "label": r.label, "note": r.note}


def order_snapshot(o: Order) -> dict:
    return {"number": o.number, "status": o.status, "customer_id": o.customer_id, "order_date": o.order_date,
            "price_mode": o.price_mode, "currency": o.currency, "discount": o.discount, "fapiao_no": o.fapiao_no,
            "net_total": o.net_total, "tax_total": o.tax_total, "gross_total": o.gross_total,
            "lines": [{"no": ln.line_no, "desc": ln.description, "qty": str(ln.quantity), "price": str(ln.unit_price),
                       "discount": str(ln.line_discount), "rate": str(ln.tax_rate), "net": str(ln.net_amount),
                       "tax": str(ln.tax_amount)} for ln in o.lines]}


# ---------- tax lookup ----------
def lookup_rate(db: Session, taxpayer_type: str, category: str, on: date, jurisdiction: str = "CN") -> TaxRate:
    """Latest valid_from wins among rows whose validity window contains `on`."""
    row = db.execute(
        select(TaxRate).where(
            TaxRate.jurisdiction == jurisdiction, TaxRate.taxpayer_type == taxpayer_type,
            TaxRate.tax_category == category, TaxRate.valid_from <= on,
            (TaxRate.valid_to.is_(None)) | (TaxRate.valid_to >= on),
        ).order_by(TaxRate.valid_from.desc(), TaxRate.id.desc()).limit(1)
    ).scalar_one_or_none()
    if row is None:
        raise HTTPException(422, f"No VAT rate configured for {taxpayer_type}/{category} on {on}")
    return row


# ---------- orders ----------
def get_order(db: Session, order_id: int, lock: bool = False) -> Order:
    q = select(Order).where(Order.id == order_id)
    if lock:
        q = q.with_for_update()
    o = db.execute(q).scalar_one_or_none()
    if o is None:
        raise HTTPException(404, "Order not found")
    return o


def _require_draft(o: Order) -> None:
    if o.status != "draft":
        raise conflict(f"Order {o.number} is '{o.status}'; lines and prices can only be edited while it is a draft")


def recompute(db: Session, o: Order, resnapshot: bool) -> None:
    """Recompute every line and the cached totals. Rate snapshots are refreshed only while the order is still
    being built (draft edits and confirmation); afterwards the stored rate on each line is used as-is."""
    taxpayer, juris = get_setting(db, "taxpayer_type"), get_setting(db, "jurisdiction")
    inputs = []
    for ln in o.lines:
        if resnapshot:
            cat = "export" if o.customer.is_export else ln.tax_category
            rate = lookup_rate(db, taxpayer, cat, o.order_date, juris)
            ln.tax_rate, ln.tax_rate_id = rate.rate, rate.id
        inputs.append(LineInput(ln.quantity, ln.unit_price, ln.line_discount, ln.tax_rate))
    try:
        res = compute_order(inputs, o.price_mode == "inclusive", o.discount)
    except ValueError as e:
        raise HTTPException(422, str(e))
    for ln, r in zip(o.lines, res):
        ln.list_amount, ln.order_discount_alloc = r.list_amount, r.order_discount_alloc
        ln.net_amount, ln.tax_amount, ln.gross_amount = r.net, r.tax, r.gross
    o.list_total = sum((r.list_amount for r in res), ZERO)
    o.discount_total = sum((r.line_discount + r.order_discount_alloc for r in res), ZERO)
    o.net_total = sum((r.net for r in res), ZERO)
    o.tax_total = sum((r.tax for r in res), ZERO)
    o.gross_total = sum((r.gross for r in res), ZERO)


def _build_lines(db: Session, o: Order, lines_in) -> list[OrderLine]:
    out = []
    for i, li in enumerate(lines_in, start=1):
        desc, cat = li.description, li.tax_category
        if li.product_id is not None:
            p = db.get(Product, li.product_id)
            if p is None:
                raise HTTPException(422, f"Product {li.product_id} not found")
            desc = desc or p.name
            cat = cat or p.tax_category
        if not desc:
            raise HTTPException(422, f"Line {i}: description or product_id is required")
        out.append(OrderLine(line_no=i, product_id=li.product_id, description=desc, quantity=li.quantity,
                             unit_price=li.unit_price, line_discount=li.line_discount, tax_category=cat or "standard",
                             tax_rate=Decimal("0"), list_amount=ZERO, order_discount_alloc=ZERO,
                             net_amount=ZERO, tax_amount=ZERO, gross_amount=ZERO))
    return out


def create_order(db: Session, user: User, data) -> Order:
    cust = db.get(Customer, data.customer_id)
    if cust is None or not cust.is_active:
        raise HTTPException(422, "Customer not found or inactive")
    o = Order(number="PENDING", customer_id=cust.id, status="draft", price_mode=data.price_mode,
              currency=data.currency or get_setting(db, "currency"), order_date=data.order_date or date.today(),
              discount=data.discount, notes=data.notes, fapiao_no=data.fapiao_no, created_by=user.id)
    o.customer = cust
    db.add(o)
    db.flush()
    o.number = f"SO-{o.order_date.year}-{o.id:06d}"
    o.lines = _build_lines(db, o, data.lines)
    recompute(db, o, resnapshot=True)
    db.flush()
    audit(db, user, "order", o.id, "create", None, order_snapshot(o))
    db.commit()
    return o


def update_order(db: Session, user: User, o: Order, data) -> Order:
    old = order_snapshot(o)
    fields = data.model_dump(exclude_unset=True)
    pricing = {"customer_id", "order_date", "price_mode", "discount", "currency"} & fields.keys()
    if pricing:
        _require_draft(o)
    elif o.status == "cancelled":
        raise conflict(f"Order {o.number} is cancelled and can no longer be changed")
    if "customer_id" in fields:
        c = db.get(Customer, fields["customer_id"])
        if c is None or not c.is_active:
            raise HTTPException(422, "Customer not found or inactive")
        o.customer_id, o.customer = c.id, c
    for k in ("order_date", "price_mode", "discount", "currency", "notes", "fapiao_no"):
        if k in fields:
            setattr(o, k, fields[k])
    if pricing:
        recompute(db, o, resnapshot=True)
    audit(db, user, "order", o.id, "update", old, order_snapshot(o))
    db.commit()
    return o


def replace_lines(db: Session, user: User, o: Order, lines_in) -> Order:
    _require_draft(o)
    old = order_snapshot(o)
    o.lines.clear()
    db.flush()
    o.lines.extend(_build_lines(db, o, lines_in))
    recompute(db, o, resnapshot=True)
    audit(db, user, "order", o.id, "lines_replaced", old, order_snapshot(o))
    db.commit()
    return o


def add_line(db: Session, user: User, o: Order, li) -> Order:
    _require_draft(o)
    old = order_snapshot(o)
    new = _build_lines(db, o, [li])[0]
    new.line_no = max((x.line_no for x in o.lines), default=0) + 1
    o.lines.append(new)
    recompute(db, o, resnapshot=True)
    audit(db, user, "order", o.id, "line_added", old, order_snapshot(o))
    db.commit()
    return o


def delete_line(db: Session, user: User, o: Order, line_id: int) -> Order:
    _require_draft(o)
    ln = next((x for x in o.lines if x.id == line_id), None)
    if ln is None:
        raise HTTPException(404, "Line not found on this order")
    old = order_snapshot(o)
    o.lines.remove(ln)
    db.flush()
    recompute(db, o, resnapshot=True)
    audit(db, user, "order", o.id, "line_deleted", old, order_snapshot(o))
    db.commit()
    return o


def payment_sums(db: Session, order_ids: list[int]) -> dict[int, tuple[Decimal, Decimal]]:
    if not order_ids:
        return {}
    paid = dict(db.execute(select(Payment.order_id, func.sum(Payment.amount)).where(Payment.order_id.in_(order_ids))
                           .group_by(Payment.order_id)).all())
    ref = dict(db.execute(select(Refund.order_id, func.sum(Refund.amount)).where(Refund.order_id.in_(order_ids))
                          .group_by(Refund.order_id)).all())
    return {i: (Decimal(paid.get(i) or 0), Decimal(ref.get(i) or 0)) for i in order_ids}


def payment_status(gross_total: Decimal, paid: Decimal, refunded: Decimal) -> str:
    if refunded > 0:
        return "refunded" if refunded >= paid else "partially_refunded"
    if paid == 0:
        return "unpaid"
    if paid < gross_total:
        return "partially_paid"
    return "paid" if paid == gross_total else "overpaid"


def transition(db: Session, user: User, o: Order, target: str) -> Order:
    if target not in TRANSITIONS[o.status]:
        order = ["confirmed", "shipped", "completed", "cancelled"]
        allowed = ", ".join(sorted(TRANSITIONS[o.status], key=order.index)) or "none (final state)"
        raise conflict(f"Cannot move order {o.number} from '{o.status}' to '{target}'. Allowed from '{o.status}': {allowed}.")
    old = order_snapshot(o)
    if target == "confirmed":
        if not o.lines:
            raise conflict("Cannot confirm an order with no lines")
        recompute(db, o, resnapshot=True)  # last chance to pick up the rate in force on the order date
    if target == "cancelled":
        paid, refunded = payment_sums(db, [o.id])[o.id]
        if paid - refunded > 0:
            raise conflict("Order has payments that are not refunded; refund them before cancelling")
    o.status = target
    audit(db, user, "order", o.id, f"status_{target}", old, order_snapshot(o))
    db.commit()
    return o


# ---------- payments & refunds ----------
def add_payment(db: Session, user: User, o: Order, data) -> Payment:
    o = get_order(db, o.id, lock=True)
    if o.status not in ("confirmed", "shipped", "completed"):
        raise conflict(f"Payments can only be recorded on confirmed, shipped or completed orders (this one is '{o.status}')")
    p = Payment(order_id=o.id, amount=data.amount, method=data.method, reference=data.reference,
                paid_at=to_utc_naive(data.paid_at, business_tz(db)), created_by=user.id)
    db.add(p)
    db.flush()
    audit(db, user, "payment", p.id, "create", None, {"order": o.number, "amount": p.amount, "method": p.method,
                                                      "reference": p.reference, "paid_at": p.paid_at})
    db.commit()
    return p


def add_refund(db: Session, user: User, payment_id: int, data) -> Refund:
    pay = db.execute(select(Payment).where(Payment.id == payment_id).with_for_update()).scalar_one_or_none()
    if pay is None:
        raise HTTPException(404, "Payment not found")
    o = get_order(db, pay.order_id, lock=True)
    already = Decimal(db.scalar(select(func.coalesce(func.sum(Refund.amount), 0)).where(Refund.payment_id == pay.id)))
    if data.amount > pay.amount - already:
        raise conflict(f"Refund of {data.amount} exceeds what is left on payment {pay.id}: "
                       f"paid {pay.amount}, already refunded {already}, refundable {pay.amount - already}")
    # VAT part is proportional to the order's tax share; a cancelled order never charged VAT in the reports
    vat_done = Decimal(db.scalar(select(func.coalesce(func.sum(Refund.vat_amount), 0)).where(Refund.order_id == o.id)))
    if o.status == "cancelled" or o.gross_total == 0:
        vat = ZERO
    else:
        vat = min(q2(data.amount * o.tax_total / o.gross_total), o.tax_total - vat_done)
    r = Refund(order_id=o.id, payment_id=pay.id, amount=data.amount, vat_amount=vat, net_amount=data.amount - vat,
               reason=data.reason, credit_note_no=data.credit_note_no,
               refunded_at=to_utc_naive(data.refunded_at, business_tz(db)), created_by=user.id)
    db.add(r)
    db.flush()
    audit(db, user, "refund", r.id, "create", None, {"order": o.number, "payment_id": pay.id, "amount": r.amount,
                                                     "vat_amount": r.vat_amount, "credit_note_no": r.credit_note_no})
    db.commit()
    return r
