from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from . import reports, schemas, services
from .db import get_db
from .models import AuditLog, Customer, Order, Payment, Product, Refund, Setting, TaxRate, User
from .security import current_user, hash_password, make_token, require_admin, require_staff, verify_password

ADMIN = [Depends(require_admin)]
STAFF = [Depends(require_staff)]

auth = APIRouter(tags=["auth"])
users = APIRouter(prefix="/users", tags=["users (admin)"])
config = APIRouter(tags=["settings and tax rates"])
masters = APIRouter(tags=["customers and products"])
orders = APIRouter(prefix="/orders", tags=["orders"])
money = APIRouter(tags=["payments and refunds"])
rep = APIRouter(prefix="/reports", tags=["reports"])
misc = APIRouter(tags=["audit"])


def paginate(db: Session, q, page: int, size: int):
    total = db.scalar(select(func.count()).select_from(q.order_by(None).subquery()))
    return total, db.scalars(q.offset((page - 1) * size).limit(size)).all()


# ---------------- auth ----------------
@auth.post("/auth/token", response_model=schemas.Token, summary="Log in (OAuth2 password flow)")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    u = db.scalar(select(User).where(User.username == form.username))
    if u is None or not u.is_active or not verify_password(form.password, u.password_hash):
        raise HTTPException(401, "Incorrect username or password", headers={"WWW-Authenticate": "Bearer"})
    return schemas.Token(access_token=make_token(u))


@auth.get("/auth/me", response_model=schemas.UserOut, summary="Current user")
def me(user: User = Depends(current_user)):
    return user


# ---------------- users ----------------
@users.get("", response_model=list[schemas.UserOut], summary="List users")
def list_users(db: Session = Depends(get_db), _=Depends(require_admin)):
    return db.scalars(select(User).order_by(User.id)).all()


@users.post("", response_model=schemas.UserOut, status_code=201, summary="Create a user")
def create_user(data: schemas.UserCreate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    u = User(username=data.username, full_name=data.full_name, role=data.role, password_hash=hash_password(data.password))
    db.add(u)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "Username already exists")
    services.audit(db, admin, "user", u.id, "create", None, {"username": u.username, "role": u.role})
    db.commit()
    return u


@users.patch("/{user_id}", response_model=schemas.UserOut, summary="Change role, active flag, name or password")
def update_user(user_id: int, data: schemas.UserUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    u = db.get(User, user_id)
    if u is None:
        raise HTTPException(404, "User not found")
    f = data.model_dump(exclude_unset=True)
    if u.id == admin.id and (f.get("is_active") is False or f.get("role") == "staff"):
        raise HTTPException(409, "You cannot deactivate or demote your own account")
    old = {"role": u.role, "is_active": u.is_active}
    if "password" in f:
        u.password_hash = hash_password(f.pop("password"))
    for k, v in f.items():
        setattr(u, k, v)
    services.audit(db, admin, "user", u.id, "update", old, {"role": u.role, "is_active": u.is_active})
    db.commit()
    return u


# ---------------- settings & tax rates ----------------
def _settings(db: Session) -> dict:
    return {s.key: s.value for s in db.scalars(select(Setting))}


@config.get("/settings", response_model=schemas.SettingsOut, dependencies=STAFF, summary="Business settings")
def get_settings_(db: Session = Depends(get_db)):
    return _settings(db)


@config.put("/settings", response_model=schemas.SettingsOut, summary="Update business settings (taxpayer type etc.)")
def put_settings(data: schemas.SettingsUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    f = data.model_dump(exclude_unset=True, exclude_none=True)
    if "timezone" in f:
        from zoneinfo import ZoneInfo
        try:
            ZoneInfo(f["timezone"])
        except Exception:
            raise HTTPException(422, "Unknown timezone")
    old = _settings(db)
    new = {**old, **f}
    known = db.scalar(select(func.count()).select_from(TaxRate).where(
        TaxRate.jurisdiction == new["jurisdiction"], TaxRate.taxpayer_type == new["taxpayer_type"]))
    if not known:
        raise HTTPException(422, f"No tax rates exist for jurisdiction '{new['jurisdiction']}' and taxpayer type "
                                 f"'{new['taxpayer_type']}'. Add rate rows first (POST /tax-rates).")
    for k, v in f.items():
        db.merge(Setting(key=k, value=v))
    db.flush()
    services.audit(db, admin, "setting", 0, "update", old, _settings(db))
    db.commit()
    return _settings(db)


@config.get("/tax-rates", response_model=list[schemas.TaxRateOut], dependencies=STAFF, summary="List VAT rates (effective-dated)")
def list_rates(taxpayer_type: str | None = None, db: Session = Depends(get_db)):
    q = select(TaxRate).order_by(TaxRate.taxpayer_type, TaxRate.tax_category, TaxRate.valid_from)
    if taxpayer_type:
        q = q.where(TaxRate.taxpayer_type == taxpayer_type)
    return db.scalars(q).all()


@config.get("/tax-rates/lookup", response_model=schemas.TaxRateOut, dependencies=STAFF,
            summary="Which rate applies for taxpayer type + category on a date")
def lookup(tax_category: str, on: date, taxpayer_type: str | None = None, jurisdiction: str | None = None,
           db: Session = Depends(get_db)):
    return services.lookup_rate(db, taxpayer_type or services.get_setting(db, "taxpayer_type"), tax_category, on,
                                jurisdiction or services.get_setting(db, "jurisdiction"))


@config.post("/tax-rates", response_model=schemas.TaxRateOut, status_code=201, summary="Add a VAT rate row")
def add_rate(data: schemas.TaxRateIn, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    r = TaxRate(**data.model_dump())
    db.add(r)
    db.flush()
    services.audit(db, admin, "tax_rate", r.id, "create", None, services.rate_snapshot(r))
    db.commit()
    return r


@config.patch("/tax-rates/{rate_id}", response_model=schemas.TaxRateOut,
              summary="Edit a rate row (existing orders keep their snapshot)")
def edit_rate(rate_id: int, data: schemas.TaxRateIn, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    r = db.get(TaxRate, rate_id)
    if r is None:
        raise HTTPException(404, "Rate not found")
    old = services.rate_snapshot(r)
    for k, v in data.model_dump().items():
        setattr(r, k, v)
    services.audit(db, admin, "tax_rate", r.id, "update", old, services.rate_snapshot(r))
    db.commit()
    return r


# ---------------- customers & products ----------------
@masters.get("/customers", dependencies=STAFF, summary="List customers (search, export filter, pagination)")
def list_customers(q: str | None = None, is_export: bool | None = None, include_inactive: bool = False,
                   page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(Customer).order_by(Customer.name)
    if q:
        stmt = stmt.where(Customer.name.like(f"%{q}%"))
    if is_export is not None:
        stmt = stmt.where(Customer.is_export == is_export)
    if not include_inactive:
        stmt = stmt.where(Customer.is_active.is_(True))
    total, items = paginate(db, stmt, page, page_size)
    return {"items": [schemas.CustomerOut.model_validate(i) for i in items], "total": total, "page": page, "page_size": page_size}


@masters.post("/customers", response_model=schemas.CustomerOut, status_code=201, dependencies=STAFF, summary="Create a customer")
def create_customer(data: schemas.CustomerIn, db: Session = Depends(get_db)):
    c = Customer(**data.model_dump())
    db.add(c)
    db.commit()
    return c


@masters.get("/customers/{cid}", response_model=schemas.CustomerOut, dependencies=STAFF, summary="Get a customer")
def get_customer(cid: int, db: Session = Depends(get_db)):
    c = db.get(Customer, cid)
    if c is None:
        raise HTTPException(404, "Customer not found")
    return c


@masters.patch("/customers/{cid}", response_model=schemas.CustomerOut, dependencies=STAFF, summary="Update a customer")
def update_customer(cid: int, data: schemas.CustomerUpdate, db: Session = Depends(get_db)):
    c = get_customer(cid, db)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(c, k, v)
    db.commit()
    return c


@masters.get("/products", dependencies=STAFF, summary="List products")
def list_products(q: str | None = None, page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200),
                  db: Session = Depends(get_db)):
    stmt = select(Product).order_by(Product.sku)
    if q:
        stmt = stmt.where(Product.name.like(f"%{q}%") | Product.sku.like(f"%{q}%"))
    total, items = paginate(db, stmt, page, page_size)
    return {"items": [schemas.ProductOut.model_validate(i) for i in items], "total": total, "page": page, "page_size": page_size}


@masters.post("/products", response_model=schemas.ProductOut, status_code=201, dependencies=STAFF, summary="Create a product")
def create_product(data: schemas.ProductIn, db: Session = Depends(get_db)):
    p = Product(**data.model_dump())
    db.add(p)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "SKU already exists")
    return p


@masters.patch("/products/{pid}", response_model=schemas.ProductOut, dependencies=STAFF, summary="Update a product")
def update_product(pid: int, data: schemas.ProductUpdate, db: Session = Depends(get_db)):
    p = db.get(Product, pid)
    if p is None:
        raise HTTPException(404, "Product not found")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(p, k, v)
    db.commit()
    return p


# ---------------- orders ----------------
def order_out(db: Session, o: Order, sums=None) -> schemas.OrderOut:
    paid, refunded = (sums or services.payment_sums(db, [o.id]))[o.id]
    out = schemas.OrderOut.model_validate(o, from_attributes=True)
    out.customer_name = o.customer.name
    out.payment_status = services.payment_status(o.gross_total, paid, refunded)
    out.paid_total, out.refunded_total = paid, refunded
    out.balance_due = max(Decimal("0.00"), o.gross_total - paid) if o.status != "cancelled" else Decimal("0.00")
    return out


def _order(db: Session, oid: int, lock=False) -> Order:
    return services.get_order(db, oid, lock)


@orders.post("", response_model=schemas.OrderOut, status_code=201, dependencies=STAFF, summary="Create an order (draft)")
def create_order(data: schemas.OrderCreate, db: Session = Depends(get_db), user: User = Depends(current_user)):
    return order_out(db, services.create_order(db, user, data))


@orders.get("", dependencies=STAFF, summary="List orders (filters: status, customer, date range, number)")
def list_orders(status: str | None = None, customer_id: int | None = None, date_from: date | None = None,
                date_to: date | None = None, q: str | None = Query(None, description="order number contains"),
                page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(Order).options(selectinload(Order.lines), selectinload(Order.customer)).order_by(Order.order_date.desc(), Order.id.desc())
    if status:
        stmt = stmt.where(Order.status == status)
    if customer_id:
        stmt = stmt.where(Order.customer_id == customer_id)
    if date_from:
        stmt = stmt.where(Order.order_date >= date_from)
    if date_to:
        stmt = stmt.where(Order.order_date <= date_to)
    if q:
        stmt = stmt.where(Order.number.like(f"%{q}%"))
    total, items = paginate(db, stmt, page, page_size)
    sums = services.payment_sums(db, [o.id for o in items])
    return {"items": [order_out(db, o, sums) for o in items], "total": total, "page": page, "page_size": page_size}


@orders.get("/{oid}", response_model=schemas.OrderOut, dependencies=STAFF, summary="Get one order with lines and payment status")
def get_order(oid: int, db: Session = Depends(get_db)):
    return order_out(db, _order(db, oid))


@orders.patch("/{oid}", response_model=schemas.OrderOut, summary="Update order header (pricing fields: draft only)")
def update_order(oid: int, data: schemas.OrderUpdate, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return order_out(db, services.update_order(db, user, _order(db, oid), data))


@orders.put("/{oid}/lines", response_model=schemas.OrderOut, summary="Replace all lines (draft only)")
def put_lines(oid: int, lines: list[schemas.LineIn], db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return order_out(db, services.replace_lines(db, user, _order(db, oid), lines))


@orders.post("/{oid}/lines", response_model=schemas.OrderOut, status_code=201, summary="Add a line (draft only)")
def post_line(oid: int, line: schemas.LineIn, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return order_out(db, services.add_line(db, user, _order(db, oid), line))


@orders.delete("/{oid}/lines/{line_id}", response_model=schemas.OrderOut, summary="Delete a line (draft only)")
def del_line(oid: int, line_id: int, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return order_out(db, services.delete_line(db, user, _order(db, oid), line_id))


@orders.post("/{oid}/status", response_model=schemas.OrderOut,
             summary="Move order: draft -> confirmed -> shipped -> completed; cancel from draft/confirmed")
def change_status(oid: int, data: schemas.StatusChange, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return order_out(db, services.transition(db, user, _order(db, oid, lock=True), data.status))


# ---------------- payments & refunds ----------------
@money.post("/orders/{oid}/payments", response_model=schemas.PaymentOut, status_code=201, summary="Record a payment")
def add_payment(oid: int, data: schemas.PaymentIn, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return services.add_payment(db, user, _order(db, oid), data)


@money.get("/orders/{oid}/payments", response_model=list[schemas.PaymentOut], dependencies=STAFF, summary="Payments of an order")
def order_payments(oid: int, db: Session = Depends(get_db)):
    _order(db, oid)
    return db.scalars(select(Payment).where(Payment.order_id == oid).order_by(Payment.paid_at)).all()


@money.post("/payments/{pid}/refunds", response_model=schemas.RefundOut, status_code=201,
            summary="Refund part or all of a payment (cannot exceed it)")
def add_refund(pid: int, data: schemas.RefundIn, db: Session = Depends(get_db), user: User = Depends(require_staff)):
    return services.add_refund(db, user, pid, data)


@money.get("/orders/{oid}/refunds", response_model=list[schemas.RefundOut], dependencies=STAFF, summary="Refunds of an order")
def order_refunds(oid: int, db: Session = Depends(get_db)):
    _order(db, oid)
    return db.scalars(select(Refund).where(Refund.order_id == oid).order_by(Refund.refunded_at)).all()


@money.get("/payments", dependencies=STAFF, summary="List payments (date range, order)")
def list_payments(order_id: int | None = None, date_from: date | None = None, date_to: date | None = None,
                  page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(Payment).order_by(Payment.paid_at.desc())
    if order_id:
        stmt = stmt.where(Payment.order_id == order_id)
    tz = services.business_tz(db)
    if date_from:
        stmt = stmt.where(Payment.paid_at >= services.local_range_to_utc(date_from, date_from, tz)[0])
    if date_to:
        stmt = stmt.where(Payment.paid_at < services.local_range_to_utc(date_to, date_to, tz)[1])
    total, items = paginate(db, stmt, page, page_size)
    return {"items": [schemas.PaymentOut.model_validate(i) for i in items], "total": total, "page": page, "page_size": page_size}


@money.get("/refunds", dependencies=STAFF, summary="List refunds (date range, order)")
def list_refunds(order_id: int | None = None, date_from: date | None = None, date_to: date | None = None,
                 page: int = Query(1, ge=1), page_size: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(Refund).order_by(Refund.refunded_at.desc())
    if order_id:
        stmt = stmt.where(Refund.order_id == order_id)
    tz = services.business_tz(db)
    if date_from:
        stmt = stmt.where(Refund.refunded_at >= services.local_range_to_utc(date_from, date_from, tz)[0])
    if date_to:
        stmt = stmt.where(Refund.refunded_at < services.local_range_to_utc(date_to, date_to, tz)[1])
    total, items = paginate(db, stmt, page, page_size)
    return {"items": [schemas.RefundOut.model_validate(i) for i in items], "total": total, "page": page, "page_size": page_size}


# ---------------- reports ----------------
@rep.get("/summary", dependencies=STAFF, summary="Monthly + quarterly + year summary for a year")
def report_summary(year: int = Query(..., ge=2000, le=2100), period: str = Query("all", pattern="^(all|month|quarter|year)$"),
                   db: Session = Depends(get_db)):
    rows = reports.ledger(db, date(year, 1, 1), date(year, 12, 31))
    s = reports.summary(rows, year)
    return reports.as_json([r for r in s if period == "all" or r["period_type"] == period])


@rep.get("/by-rate", dependencies=STAFF, summary="Net sales and output VAT per VAT rate and period")
def report_by_rate(year: int = Query(..., ge=2000, le=2100), db: Session = Depends(get_db)):
    return reports.as_json(reports.by_rate(reports.ledger(db, date(year, 1, 1), date(year, 12, 31)), year))


@rep.get("/by-customer", dependencies=STAFF, summary="Per-customer breakdown for a date range")
def report_by_customer(date_from: date, date_to: date, db: Session = Depends(get_db)):
    return reports.as_json(reports.by_customer(reports.ledger(db, date_from, date_to), date_from, date_to))


@rep.get("/transactions", dependencies=STAFF, summary="Ledger: every order line, payment and refund (paginated)")
def report_transactions(date_from: date, date_to: date, type: str | None = Query(None, pattern="^(order_line|payment|refund)$"),
                        page: int = Query(1, ge=1), page_size: int = Query(200, ge=1, le=1000), db: Session = Depends(get_db)):
    rows = [r for r in reports.ledger(db, date_from, date_to) if not type or r["type"] == type]
    return {"items": reports.as_json(rows[(page - 1) * page_size: page * page_size]), "total": len(rows), "page": page, "page_size": page_size}


@rep.get("/export.csv", dependencies=STAFF, summary="CSV export of one report")
def export_csv(year: int = Query(..., ge=2000, le=2100),
               kind: str = Query("transactions", pattern="^(summary|by_rate|by_customer|transactions)$"),
               db: Session = Depends(get_db)):
    data = reports.build_datasets(db, year)[kind]
    return Response(reports.to_csv(kind, data), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{kind}-{year}.csv"'})


@rep.get("/export.xlsx", dependencies=STAFF, summary="Excel workbook: Summary, By rate, By customer, Transactions")
def export_xlsx(year: int = Query(..., ge=2000, le=2100), db: Session = Depends(get_db)):
    return Response(reports.to_xlsx(reports.build_datasets(db, year), year),
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f'attachment; filename="report-{year}.xlsx"'})


# ---------------- audit ----------------
@misc.get("/audit-log", dependencies=ADMIN, summary="Audit trail (admin): who changed what, old and new values")
def audit_log(entity: str | None = None, entity_id: int | None = None, page: int = Query(1, ge=1),
              page_size: int = Query(50, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(AuditLog).order_by(AuditLog.id.desc())
    if entity:
        stmt = stmt.where(AuditLog.entity == entity)
    if entity_id:
        stmt = stmt.where(AuditLog.entity_id == entity_id)
    total, items = paginate(db, stmt, page, page_size)
    return {"items": [schemas.AuditOut.model_validate(i) for i in items], "total": total, "page": page, "page_size": page_size}
