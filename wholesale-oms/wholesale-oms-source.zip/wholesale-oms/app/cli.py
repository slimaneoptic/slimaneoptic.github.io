"""Admin commands.
  python -m app.cli init-db                      create tables, seed tax rates + settings (safe to repeat)
  python -m app.cli create-admin USERNAME        bootstrap the first admin; password is prompted
                                                 (or read from env OMS_ADMIN_PASSWORD for scripts)
"""
import getpass
import os
import sys

from sqlalchemy import select

from .db import Base, SessionLocal, engine
from .models import User
from .rates_seed import seed_defaults
from .security import hash_password


def init_db() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        seed_defaults(db)
    print("Database ready.")


def create_admin(username: str) -> None:
    pw = os.environ.get("OMS_ADMIN_PASSWORD") or getpass.getpass("Password (min 10 chars): ")
    if len(pw) < 10:
        sys.exit("Password must be at least 10 characters.")
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.username == username)):
            sys.exit(f"User '{username}' already exists.")
        db.add(User(username=username, full_name="Administrator", role="admin", password_hash=hash_password(pw)))
        db.commit()
    print(f"Admin '{username}' created.")


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["init-db"]:
        init_db()
    elif a[:1] == ["create-admin"] and len(a) == 2:
        create_admin(a[1])
    else:
        sys.exit(__doc__)
