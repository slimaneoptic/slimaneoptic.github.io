"""Reports are all derived from ONE ledger (every order line, payment and refund), so the summaries and the
accounting export can never disagree."""
import csv
import io
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from sqlalchemy import select
from sqlalchemy.orm import Session

from .models import Customer, Order, OrderLine, Payment, Refund
from .services import business_tz, local_date, local_range_to_utc
from .tax import allocate, q2

ZERO = Decimal("0.00")
COUNTED = ("confirmed", "shipped", "completed")  # drafts and cancelled orders are not sales


def _refund_split(o: Order, r: Refund):
    """Spread a refund over the order's rate groups (gross by line value, VAT by tax share); last group takes the
    remainder so the pieces add up to the refund exactly."""
    groups: dict[Decimal, list[Decimal]] = defaultdict(lambda: [ZERO, ZERO])
    for ln in o.lines:
        groups[ln.tax_rate][0] += ln.gross_amount
        groups[ln.tax_rate][1] += ln.tax_amount
    rates = sorted(groups)
    if not rates:
        return [(None, r.amount, r.vat_amount)]
    gross = allocate(r.amount, [groups[x][0] for x in rates])
    vat = allocate(r.vat_amount, [groups[x][1] for x in rates])
    return list(zip(rates, gross, vat))


def ledger(db: Session, d_from: date, d_to: date) -> list[dict]:
    tz = business_tz(db)
    rows: list[dict] = []
    q = (select(OrderLine, Order, Customer).join(Order, OrderLine.order_id == Order.id)
         .join(Customer, Order.customer_id == Customer.id)
         .where(Order.order_date >= d_from, Order.order_date <= d_to, Order.status.in_(COUNTED))
         .order_by(Order.order_date, Order.id, OrderLine.line_no))
    for ln, o, c in db.execute(q):
        rows.append(dict(date=o.order_date, type="order_line", document=o.number, order_id=o.id, customer_id=c.id,
                         customer=c.name, description=ln.description, currency=o.currency, rate=ln.tax_rate,
                         list_amount=ln.list_amount, discount=ln.line_discount + ln.order_discount_alloc,
                         net=ln.net_amount, vat=ln.tax_amount, gross=ln.gross_amount, reference=o.fapiao_no or ""))
    a, b = local_range_to_utc(d_from, d_to, tz)
    q = (select(Payment, Order, Customer).join(Order, Payment.order_id == Order.id)
         .join(Customer, Order.customer_id == Customer.id)
         .where(Payment.paid_at >= a, Payment.paid_at < b).order_by(Payment.paid_at, Payment.id))
    for p, o, c in db.execute(q):
        rows.append(dict(date=local_date(p.paid_at, tz), type="payment", document=o.number, order_id=o.id,
                         customer_id=c.id, customer=c.name, description=f"Payment ({p.method})", currency=o.currency,
                         rate=None, list_amount=ZERO, discount=ZERO, net=ZERO, vat=ZERO, gross=p.amount,
                         reference=p.reference))
    q = (select(Refund, Order, Customer).join(Order, Refund.order_id == Order.id)
         .join(Customer, Order.customer_id == Customer.id)
         .where(Refund.refunded_at >= a, Refund.refunded_at < b).order_by(Refund.refunded_at, Refund.id))
    for r, o, c in db.execute(q):
        for rate, gross, vat in _refund_split(o, r):
            rows.append(dict(date=local_date(r.refunded_at, tz), type="refund", document=o.number, order_id=o.id,
                             customer_id=c.id, customer=c.name, description=f"Refund: {r.reason}".strip(": "),
                             currency=o.currency, rate=rate, list_amount=ZERO, discount=ZERO, net=-(gross - vat),
                             vat=-vat, gross=-gross, reference=r.credit_note_no or ""))
    return rows


def _periods(year: int):
    out = []
    for m in range(1, 13):
        end = (date(year + (m == 12), m % 12 + 1, 1) - timedelta(days=1))
        out.append(("month", f"{year}-{m:02d}", date(year, m, 1), end))
    for qn in range(1, 5):
        s, e = date(year, 3 * qn - 2, 1), date(year + (qn == 4), (3 * qn) % 12 + 1, 1) - timedelta(days=1)
        out.append(("quarter", f"{year}-Q{qn}", s, e))
    out.append(("year", str(year), date(year, 1, 1), date(year, 12, 31)))
    return out


def _outstanding(rows: list[dict], start: date, end: date) -> Decimal:
    inv: dict[str, Decimal] = defaultdict(lambda: ZERO)
    paid: dict[str, Decimal] = defaultdict(lambda: ZERO)
    for r in rows:
        if r["type"] == "order_line" and start <= r["date"] <= end:
            inv[r["document"]] += r["gross"]
    for r in rows:
        if r["type"] == "payment" and r["document"] in inv and r["date"] <= end:
            paid[r["document"]] += r["gross"]
    return sum((max(ZERO, v - paid[k]) for k, v in inv.items()), ZERO)


def _agg(rows, start, end):
    lines = [r for r in rows if r["type"] == "order_line" and start <= r["date"] <= end]
    pays = [r for r in rows if r["type"] == "payment" and start <= r["date"] <= end]
    refs = [r for r in rows if r["type"] == "refund" and start <= r["date"] <= end]
    S = lambda xs, k: sum((x[k] for x in xs), ZERO)
    d = dict(
        orders=len({r["document"] for r in lines}),
        gross_before_discount=S(lines, "list_amount"), discounts=S(lines, "discount"),
        net_sales=S(lines, "net"), output_vat=S(lines, "vat"), total_invoiced=S(lines, "gross"),
        refunds_gross=-S(refs, "gross"), refunds_net=-S(refs, "net"), refunds_vat=-S(refs, "vat"),
        payments_received=S(pays, "gross"), outstanding_receivables=_outstanding(rows, start, end))
    d["net_sales_after_refunds"] = d["net_sales"] - d["refunds_net"]
    d["vat_after_refunds"] = d["output_vat"] - d["refunds_vat"]
    return d


def summary(rows: list[dict], year: int) -> list[dict]:
    return [dict(period_type=pt, period=label, **_agg(rows, s, e)) for pt, label, s, e in _periods(year)]


def by_rate(rows: list[dict], year: int) -> list[dict]:
    out = []
    for pt, label, s, e in _periods(year):
        grp: dict[Decimal, dict] = {}
        for r in rows:
            if r["type"] == "payment" or not (s <= r["date"] <= e):
                continue
            g = grp.setdefault(r["rate"], dict(net_sales=ZERO, output_vat=ZERO, refunds_net=ZERO, refunds_vat=ZERO))
            if r["type"] == "order_line":
                g["net_sales"] += r["net"]
                g["output_vat"] += r["vat"]
            else:
                g["refunds_net"] -= r["net"]
                g["refunds_vat"] -= r["vat"]
        for rate in sorted(grp, key=lambda x: (x is None, x)):
            g = grp[rate]
            out.append(dict(period_type=pt, period=label, rate=rate, **g,
                            net_after_refunds=g["net_sales"] - g["refunds_net"],
                            vat_after_refunds=g["output_vat"] - g["refunds_vat"]))
    return out


def by_customer(rows: list[dict], d_from: date, d_to: date) -> list[dict]:
    ids = sorted({r["customer_id"] for r in rows}, key=lambda i: next(r["customer"] for r in rows if r["customer_id"] == i))
    out = []
    for cid in ids:
        sub = [r for r in rows if r["customer_id"] == cid]
        a = _agg(sub, d_from, d_to)
        out.append(dict(customer=sub[0]["customer"], **{k: a[k] for k in (
            "orders", "net_sales", "output_vat", "total_invoiced", "discounts", "refunds_gross", "payments_received",
            "outstanding_receivables")}))
    return out


def as_json(rows):
    """Decimals become exact strings (FastAPI would otherwise turn them into floats)."""
    if isinstance(rows, dict):
        return {k: as_json(v) for k, v in rows.items()}
    if isinstance(rows, list):
        return [as_json(r) for r in rows]
    return str(rows) if isinstance(rows, Decimal) else rows


# ---------- export ----------
FMT_MONEY, FMT_RATE, FMT_DATE, FMT_INT = "#,##0.00", "0.00%", "yyyy-mm-dd", "0"
SUMMARY_COLS = [("period_type", "Period type", None, 12), ("period", "Period", None, 12), ("orders", "Orders", FMT_INT, 9),
                ("gross_before_discount", "Gross before discounts", FMT_MONEY, 20), ("discounts", "Discounts", FMT_MONEY, 14),
                ("net_sales", "Net sales", FMT_MONEY, 16), ("output_vat", "Output VAT", FMT_MONEY, 14),
                ("total_invoiced", "Total invoiced", FMT_MONEY, 16), ("refunds_net", "Refunds (net)", FMT_MONEY, 15),
                ("refunds_vat", "Refunds (VAT)", FMT_MONEY, 15), ("refunds_gross", "Refunds (total)", FMT_MONEY, 15),
                ("net_sales_after_refunds", "Net sales after refunds", FMT_MONEY, 22),
                ("vat_after_refunds", "VAT after refunds", FMT_MONEY, 18), ("payments_received", "Payments received", FMT_MONEY, 18),
                ("outstanding_receivables", "Outstanding receivables", FMT_MONEY, 22)]
RATE_COLS = [("period_type", "Period type", None, 12), ("period", "Period", None, 12), ("rate", "VAT rate", FMT_RATE, 10),
             ("net_sales", "Net sales", FMT_MONEY, 16), ("output_vat", "Output VAT", FMT_MONEY, 14),
             ("refunds_net", "Refunds (net)", FMT_MONEY, 15), ("refunds_vat", "Refunds (VAT)", FMT_MONEY, 15),
             ("net_after_refunds", "Net after refunds", FMT_MONEY, 18), ("vat_after_refunds", "VAT after refunds", FMT_MONEY, 18)]
CUSTOMER_COLS = [("customer", "Customer", None, 30), ("orders", "Orders", FMT_INT, 9), ("net_sales", "Net sales", FMT_MONEY, 16),
                 ("output_vat", "Output VAT", FMT_MONEY, 14), ("total_invoiced", "Total invoiced", FMT_MONEY, 16),
                 ("discounts", "Discounts", FMT_MONEY, 14), ("refunds_gross", "Refunds (total)", FMT_MONEY, 15),
                 ("payments_received", "Payments received", FMT_MONEY, 18), ("outstanding_receivables", "Outstanding", FMT_MONEY, 16)]
LEDGER_COLS = [("date", "Date", FMT_DATE, 12), ("type", "Type", None, 11), ("document", "Order no.", None, 18),
               ("customer", "Customer", None, 28), ("description", "Description", None, 36), ("currency", "Cur.", None, 6),
               ("rate", "VAT rate", FMT_RATE, 10), ("list_amount", "Value before discount", FMT_MONEY, 20),
               ("discount", "Discount", FMT_MONEY, 12), ("net", "Net", FMT_MONEY, 14), ("vat", "VAT", FMT_MONEY, 12),
               ("gross", "Total", FMT_MONEY, 14), ("reference", "Fapiao / reference", None, 22)]
DATASETS = {"summary": ("Summary", SUMMARY_COLS), "by_rate": ("By rate", RATE_COLS),
            "by_customer": ("By customer", CUSTOMER_COLS), "transactions": ("Transactions", LEDGER_COLS)}


def build_datasets(db: Session, year: int) -> dict[str, list[dict]]:
    d_from, d_to = date(year, 1, 1), date(year, 12, 31)
    rows = ledger(db, d_from, d_to)
    return {"summary": summary(rows, year), "by_rate": by_rate(rows, year),
            "by_customer": by_customer(rows, d_from, d_to), "transactions": rows}


def to_csv(kind: str, data: list[dict]) -> bytes:
    cols = DATASETS[kind][1]
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow([c[1] for c in cols])
    for r in data:
        w.writerow(["" if r.get(k) is None else (str(r[k]) if not isinstance(r[k], Decimal) or fmt != FMT_RATE
                                                  else f"{r[k]:.4f}") for k, _, fmt, _ in cols])
    return ("﻿" + buf.getvalue()).encode("utf-8")  # BOM so Excel opens Chinese text correctly


def to_xlsx(sets: dict[str, list[dict]], year: int) -> bytes:
    wb = Workbook()
    wb.remove(wb.active)
    head_fill = PatternFill("solid", fgColor="1F3A5F")
    for kind, (title, cols) in DATASETS.items():
        ws = wb.create_sheet(title)
        ws.append([c[1] for c in cols])
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = head_fill
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.row_dimensions[1].height = 32
        for r in sets[kind]:
            ws.append([r.get(k) for k, _, _, _ in cols])
        for i, (_, _, fmt, width) in enumerate(cols, start=1):
            ws.column_dimensions[get_column_letter(i)].width = width
            if fmt:
                for cell in ws.iter_cols(min_col=i, max_col=i, min_row=2).__next__():
                    cell.number_format = fmt
        if kind == "summary":  # make year/quarter total rows stand out
            for row in ws.iter_rows(min_row=2):
                if row[0].value in ("quarter", "year"):
                    for c in row:
                        c.font = Font(bold=row[0].value == "year")
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
    wb.properties.title = f"Order and VAT report {year}"
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()
