"""Pure tax arithmetic. Decimal only, ROUND_HALF_UP to 0.01 per line. No database, no rates hard-coded."""
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

ZERO = Decimal("0.00")
CENT = Decimal("0.01")


def q2(x: Decimal) -> Decimal:
    return Decimal(x).quantize(CENT, rounding=ROUND_HALF_UP)


def allocate(total: Decimal, weights: list[Decimal]) -> list[Decimal]:
    """Split `total` in proportion to `weights`; the last share takes the rounding remainder,
    so the shares always add up to `total` exactly."""
    n = len(weights)
    if n == 0:
        return []
    wsum = sum(weights, Decimal("0"))
    if total == 0 or wsum == 0:
        return [ZERO] * n
    shares: list[Decimal] = []
    for w in weights[:-1]:
        shares.append(q2(total * w / wsum))
    shares.append(q2(total - sum(shares, Decimal("0"))))
    return shares


@dataclass
class LineInput:
    quantity: Decimal
    unit_price: Decimal
    line_discount: Decimal
    rate: Decimal


@dataclass
class LineResult:
    list_amount: Decimal
    line_discount: Decimal
    order_discount_alloc: Decimal
    net: Decimal
    tax: Decimal
    gross: Decimal


def split_amount(amount: Decimal, rate: Decimal, inclusive: bool) -> tuple[Decimal, Decimal, Decimal]:
    """Return (net, tax, gross) for an amount quoted tax-inclusive or tax-exclusive."""
    if inclusive:
        gross = q2(amount)
        net = q2(gross / (1 + rate))
        return net, gross - net, gross
    net = q2(amount)
    tax = q2(net * rate)
    return net, tax, net + tax


def compute_order(lines: list[LineInput], inclusive: bool, order_discount: Decimal) -> list[LineResult]:
    values = []
    for ln in lines:
        listed = q2(ln.quantity * ln.unit_price)
        if ln.line_discount > listed:
            raise ValueError("line discount is larger than the line value")
        values.append(listed)
    after_line = [v - ln.line_discount for v, ln in zip(values, lines)]
    if order_discount > sum(after_line, Decimal("0")):
        raise ValueError("order discount is larger than the order value")
    alloc = allocate(order_discount, after_line)
    out = []
    for ln, listed, base, a in zip(lines, values, after_line, alloc):
        net, tax, gross = split_amount(base - a, ln.rate, inclusive)
        out.append(LineResult(listed, ln.line_discount, a, net, tax, gross))
    return out
