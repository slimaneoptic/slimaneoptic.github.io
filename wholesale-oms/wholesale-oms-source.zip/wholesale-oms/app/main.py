from fastapi import FastAPI

from . import routers

DESCRIPTION = """Order management and VAT reporting for a wholesale business.

Authenticate with `POST /auth/token` (username + password), then send `Authorization: Bearer <token>`.
Roles: **admin** (users, tax rates, settings, audit log, plus everything staff can do) and **staff**
(customers, orders, payments, refunds, reports). Money is returned as exact decimal strings.
Default tax preset: China VAT (2026 VAT Law); rates are data in the `tax_rates` table, please confirm with your accountant."""

app = FastAPI(title="Wholesale Order & VAT Reporting API", version="1.0.0", description=DESCRIPTION)
for r in (routers.auth, routers.users, routers.config, routers.masters, routers.orders, routers.money, routers.rep, routers.misc):
    app.include_router(r)


@app.get("/health", tags=["system"], summary="Liveness check")
def health():
    return {"status": "ok"}
