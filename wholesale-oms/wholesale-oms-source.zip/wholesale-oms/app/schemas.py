from datetime import date, datetime
from decimal import Decimal
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field

from pydantic import PlainSerializer

# output types: exact decimal strings with fixed places
M2 = Annotated[Decimal, PlainSerializer(lambda v: f"{v:.2f}", return_type=str, when_used="json")]
R4 = Annotated[Decimal, PlainSerializer(lambda v: f"{v:.4f}", return_type=str, when_used="json")]
UTC = Annotated[datetime, PlainSerializer(
    lambda v: v.isoformat() + "Z" if v.tzinfo is None else v.isoformat(), return_type=str, when_used="json")]  # stored as UTC
Q3 = Annotated[Decimal, PlainSerializer(lambda v: f"{v:.3f}", return_type=str, when_used="json")]
Cat = Annotated[str, Field(pattern="^[a-z_]{1,16}$", description="tax category, e.g. standard / reduced / service (any category that has rate rows)")]


class ORM(BaseModel):
    model_config = ConfigDict(from_attributes=True)


class Page(BaseModel):
    items: list
    total: int
    page: int
    page_size: int


# auth / users
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(ORM):
    id: int
    username: str
    full_name: str
    role: str
    is_active: bool


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=10, max_length=72)
    full_name: str = ""
    role: Literal["admin", "staff"] = "staff"


class UserUpdate(BaseModel):
    full_name: str | None = None
    role: Literal["admin", "staff"] | None = None
    is_active: bool | None = None
    password: str | None = Field(default=None, min_length=10, max_length=72)


# settings / rates
class SettingsOut(BaseModel):
    jurisdiction: str
    taxpayer_type: str
    business_name: str
    currency: str
    timezone: str


class SettingsUpdate(BaseModel):
    jurisdiction: str | None = Field(default=None, max_length=8)
    taxpayer_type: str | None = Field(default=None, max_length=16)
    business_name: str | None = Field(default=None, max_length=160)
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    timezone: str | None = None


class TaxRateIn(BaseModel):
    jurisdiction: str = "CN"
    taxpayer_type: str = Field(max_length=16)
    tax_category: str = Field(max_length=16)
    rate: Decimal = Field(ge=0, lt=1, decimal_places=4)
    valid_from: date
    valid_to: date | None = None
    label: str = ""
    note: str = ""


class TaxRateOut(TaxRateIn, ORM):
    id: int


# customers / products
class CustomerIn(BaseModel):
    name: str = Field(min_length=1, max_length=160)
    tax_id: str | None = Field(default=None, max_length=40)
    address: str = ""
    contact: str = ""
    is_export: bool = False


class CustomerUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=160)
    tax_id: str | None = None
    address: str | None = None
    contact: str | None = None
    is_export: bool | None = None
    is_active: bool | None = None


class CustomerOut(CustomerIn, ORM):
    id: int
    is_active: bool


class ProductIn(BaseModel):
    sku: str = Field(min_length=1, max_length=64)
    name: str = Field(min_length=1, max_length=160)
    unit: str = "pcs"
    tax_category: Cat = "standard"
    default_price: Decimal = Field(default=Decimal("0"), ge=0, decimal_places=2)


class ProductUpdate(BaseModel):
    name: str | None = None
    unit: str | None = None
    tax_category: Cat | None = None
    default_price: Decimal | None = Field(default=None, ge=0, decimal_places=2)
    is_active: bool | None = None


class ProductOut(ProductIn, ORM):
    id: int
    is_active: bool


# orders
class LineIn(BaseModel):
    product_id: int | None = None
    description: str = Field(default="", max_length=200)
    quantity: Decimal = Field(gt=0, decimal_places=3, max_digits=14)
    unit_price: Decimal = Field(ge=0, decimal_places=2, max_digits=14)
    line_discount: Decimal = Field(default=Decimal("0"), ge=0, decimal_places=2)
    tax_category: Cat | None = None


class LineOut(ORM):
    id: int
    line_no: int
    product_id: int | None
    description: str
    quantity: Q3
    unit_price: M2
    line_discount: M2
    tax_category: str
    tax_rate: R4
    list_amount: M2
    order_discount_alloc: M2
    net_amount: M2
    tax_amount: M2
    gross_amount: M2


class OrderCreate(BaseModel):
    customer_id: int
    order_date: date | None = None
    price_mode: Literal["inclusive", "exclusive"] = "inclusive"
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    discount: Decimal = Field(default=Decimal("0"), ge=0, decimal_places=2)
    notes: str = ""
    fapiao_no: str | None = Field(default=None, max_length=40)
    lines: list[LineIn] = []


class OrderUpdate(BaseModel):
    customer_id: int | None = None
    order_date: date | None = None
    price_mode: Literal["inclusive", "exclusive"] | None = None
    currency: str | None = Field(default=None, min_length=3, max_length=3)
    discount: Decimal | None = Field(default=None, ge=0, decimal_places=2)
    notes: str | None = None
    fapiao_no: str | None = Field(default=None, max_length=40)


class StatusChange(BaseModel):
    status: Literal["draft", "confirmed", "shipped", "completed", "cancelled"]


class OrderOut(ORM):
    id: int
    number: str
    customer_id: int
    customer_name: str = ""
    status: str
    payment_status: str = ""
    price_mode: str
    currency: str
    order_date: date
    discount: M2
    notes: str
    fapiao_no: str | None
    list_total: M2
    discount_total: M2
    net_total: M2
    tax_total: M2
    gross_total: M2
    paid_total: M2 = Decimal("0.00")
    refunded_total: M2 = Decimal("0.00")
    balance_due: M2 = Decimal("0.00")
    lines: list[LineOut] = []


# payments / refunds
class PaymentIn(BaseModel):
    amount: Decimal = Field(gt=0, decimal_places=2, max_digits=14)
    method: str = Field(default="bank_transfer", max_length=24)
    reference: str = Field(default="", max_length=80)
    paid_at: datetime | None = None


class PaymentOut(ORM):
    id: int
    order_id: int
    amount: M2
    method: str
    reference: str
    paid_at: UTC


class RefundIn(BaseModel):
    amount: Decimal = Field(gt=0, decimal_places=2, max_digits=14)
    reason: str = Field(default="", max_length=200)
    credit_note_no: str | None = Field(default=None, max_length=40)
    refunded_at: datetime | None = None


class RefundOut(ORM):
    id: int
    order_id: int
    payment_id: int
    amount: M2
    vat_amount: M2
    net_amount: M2
    reason: str
    credit_note_no: str | None
    refunded_at: UTC


class AuditOut(ORM):
    id: int
    at: UTC
    username: str
    entity: str
    entity_id: int
    action: str
    old_value: dict | None
    new_value: dict | None
